# Keep Media3 defaults; nothing custom is reflected on in this project.
-dontwarn androidx.media3.**
