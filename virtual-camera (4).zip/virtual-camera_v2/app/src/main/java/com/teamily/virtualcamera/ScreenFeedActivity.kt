package com.teamily.virtualcamera

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.SurfaceHolder
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.teamily.virtualcamera.camera.FrameBus
import com.teamily.virtualcamera.camera.SurfaceFrameWriter
import com.teamily.virtualcamera.data.AppStateStore
import com.teamily.virtualcamera.databinding.ActivityScreenFeedBinding
import com.teamily.virtualcamera.media.MediaEngine
import com.teamily.virtualcamera.service.VirtualCameraService

/**
 * The fullscreen media feed that the user **screencasts** into YouTube Live.
 *
 * ## Why this screen exists
 * YouTube's Android app cannot be handed a third-party camera — its in-app camera
 * opens Camera2 directly. But YouTube *does* offer "Screencast", which streams the
 * phone's screen. So the working no-root path is:
 *
 *   1. Open this screen (media fills the display, no chrome).
 *   2. In YouTube: Create → Go live → **Screencast** → start.
 *   3. Switch back here. The audience sees the media, not the real camera.
 *
 * ## Details that matter for a live stream
 *  - **Keep screen on** and **no chrome**: anything drawn here is broadcast, so the
 *    hint bar auto-hides after a few seconds and comes back on tap.
 *  - **Landscape is not forced**: YouTube screencast follows the device, and forcing
 *    an orientation would letterbox the stream on some devices.
 *  - **Runs its own engine if the service is not up**, so this screen works even if
 *    the user never started the virtual camera — one less thing to get wrong before
 *    going live.
 *  - **Renders through [SurfaceFrameWriter]**, the same path the camera output uses,
 *    so the Fit/Fill/Stretch/Free layout applies here too.
 */
class ScreenFeedActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScreenFeedBinding
    private var engine: MediaEngine? = null
    private var writer: SurfaceFrameWriter? = null
    private var ownsEngine = false

    private val main = Handler(Looper.getMainLooper())
    private val hideHint = Runnable {
        binding.feedHintBar.animate().alpha(0f).setDuration(300).withEndAction {
            binding.feedHintBar.visibility = View.GONE
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScreenFeedBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val state = AppStateStore.load(this)
        val selection = state.active
        if (selection == null) {
            binding.feedHint.setText(R.string.feed_no_media)
            binding.feedProgress.visibility = View.GONE
            binding.feedExit.setOnClickListener { finish() }
            return
        }

        // Reuse the service's decoder when it is already running; otherwise run one
        // here so this screen is self-sufficient.
        if (!VirtualCameraService.isRunning) {
            engine = MediaEngine(applicationContext).also { eng ->
                ownsEngine = true
                eng.onStateChanged = { st, msg ->
                    runOnUiThread {
                        binding.feedProgress.visibility =
                            if (st == MediaEngine.State.PREPARING) View.VISIBLE else View.GONE
                        if (st == MediaEngine.State.ERROR) {
                            binding.feedHint.text = msg ?: getString(R.string.feed_error)
                            binding.feedHintBar.visibility = View.VISIBLE
                        }
                    }
                }
                eng.start(selection)
            }
        }

        binding.feedSurface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) = startWriter(holder)

            override fun surfaceChanged(
                holder: SurfaceHolder,
                format: Int,
                width: Int,
                height: Int
            ) {
                writer?.stop()
                startWriter(holder)
            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                writer?.stop()
                writer = null
            }
        })

        binding.feedExit.setOnClickListener { finish() }

        // Tap anywhere to bring the hint back, then auto-hide again.
        binding.feedSurface.setOnClickListener {
            binding.feedHintBar.visibility = View.VISIBLE
            binding.feedHintBar.alpha = 1f
            main.removeCallbacks(hideHint)
            main.postDelayed(hideHint, 4000)
        }
        main.postDelayed(hideHint, 5000)
    }

    private fun startWriter(holder: SurfaceHolder) {
        val w = SurfaceFrameWriter(
            target = holder.surface,
            width = (holder.surfaceFrame?.width() ?: FrameBus.FRAME_WIDTH).coerceAtLeast(2),
            height = (holder.surfaceFrame?.height() ?: FrameBus.FRAME_HEIGHT).coerceAtLeast(2),
            fps = 30,
            label = "ScreenFeedWriter"
        )
        w.listener = object : SurfaceFrameWriter.Listener {
            override fun onFirstFrameWritten() {
                runOnUiThread { binding.feedProgress.visibility = View.GONE }
            }

            override fun onWriterStopped() = Unit
        }
        writer = w
        w.start()
    }

    override fun onDestroy() {
        main.removeCallbacks(hideHint)
        writer?.stop()
        writer = null
        if (ownsEngine) {
            engine?.release()
            engine = null
        }
        super.onDestroy()
    }
}
