package com.teamily.virtualcamera.data

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * The whole persisted state of the app, in one object.
 *
 * Why two slots (video + image) instead of one selection: the overlay's
 * "video / image" toggle has to be instant — a live stream cannot wait for a file
 * picker. So each kind keeps its own last-used URI and the toggle just flips
 * [activeKind]. Everything survives process death, reboot and the bubble being
 * killed and restarted.
 */
data class AppState(
    val videoUri: Uri? = null,
    val videoName: String? = null,
    val imageUri: Uri? = null,
    val imageName: String? = null,
    val activeKind: MediaKind = MediaKind.VIDEO,
    /** Master on/off for the virtual camera feed (the bubble's big switch). */
    val enabled: Boolean = false,
    /** Whether the floating bubble should be shown over other apps. */
    val overlayBubble: Boolean = false,
    val bubbleX: Int = -1,
    val bubbleY: Int = -1,
    val recents: List<RecentMedia> = emptyList()
) {

    /** The media currently being emitted, honouring [activeKind]. */
    val active: MediaSelection?
        get() = when (activeKind) {
            MediaKind.VIDEO -> videoUri?.let {
                MediaSelection(it, MediaKind.VIDEO, videoName ?: "video")
            }
            MediaKind.IMAGE -> imageUri?.let {
                MediaSelection(it, MediaKind.IMAGE, imageName ?: "image")
            }
        }

    /** True when a file of the *other* kind exists, so the toggle is meaningful. */
    val hasBothKinds: Boolean get() = videoUri != null && imageUri != null

    fun uriFor(kind: MediaKind): Uri? = if (kind == MediaKind.VIDEO) videoUri else imageUri

    fun nameFor(kind: MediaKind): String? = if (kind == MediaKind.VIDEO) videoName else imageName

    /**
     * Applies a new pick to the right slot. If that kind was not the active one,
     * the picker also makes it active — picking a file always means "use this".
     */
    fun withPicked(uri: Uri, kind: MediaKind, name: String): AppState {
        val recents = (
            listOf(RecentMedia(uri, kind, name)) +
                recents.filterNot { it.uri == uri }
            ).take(MAX_RECENTS)

        return if (kind == MediaKind.VIDEO) {
            copy(
                videoUri = uri,
                videoName = name,
                activeKind = MediaKind.VIDEO,
                recents = recents
            )
        } else {
            copy(
                imageUri = uri,
                imageName = name,
                activeKind = MediaKind.IMAGE,
                recents = recents
            )
        }
    }

    fun withActiveKind(kind: MediaKind): AppState =
        if (uriFor(kind) == null) this else copy(activeKind = kind)

    fun withEnabled(value: Boolean): AppState = copy(enabled = value)

    fun withBubbleVisible(value: Boolean): AppState = copy(overlayBubble = value)

    fun withBubblePosition(x: Int, y: Int): AppState = copy(bubbleX = x, bubbleY = y)

    /** Drops a recent entry (used by the panel's long-press-to-remove). */
    fun withoutRecent(uri: Uri): AppState = copy(
        recents = recents.filterNot { it.uri == uri }
    )

    companion object {
        const val MAX_RECENTS = 12
    }
}

/** One entry in the "recently used" strip. Display-only; the URI may go stale. */
data class RecentMedia(
    val uri: Uri,
    val kind: MediaKind,
    val name: String
)

/**
 * SharedPreferences persistence for [AppState], and the only place that fires
 * [StateHub] events — so every writer of state also announces it.
 */
object AppStateStore {

    private const val PREFS = "vc_app_state"
    private const val K_VIDEO_URI = "video_uri"
    private const val K_VIDEO_NAME = "video_name"
    private const val K_IMAGE_URI = "image_uri"
    private const val K_IMAGE_NAME = "image_name"
    private const val K_KIND = "active_kind"
    private const val K_ENABLED = "enabled"
    private const val K_BUBBLE = "overlay_bubble"
    private const val K_BUBBLE_X = "bubble_x"
    private const val K_BUBBLE_Y = "bubble_y"
    private const val K_RECENTS = "recents"
    private const val RECENT_SEP = "\u0001"
    private const val FIELD_SEP = "\u0002"

    fun load(context: Context): AppState {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return AppState(
            videoUri = p.getString(K_VIDEO_URI, null)?.let(Uri::parse),
            videoName = p.getString(K_VIDEO_NAME, null),
            imageUri = p.getString(K_IMAGE_URI, null)?.let(Uri::parse),
            imageName = p.getString(K_IMAGE_NAME, null),
            activeKind = runCatching {
                MediaKind.valueOf(p.getString(K_KIND, MediaKind.VIDEO.name)!!)
            }.getOrDefault(MediaKind.VIDEO),
            enabled = p.getBoolean(K_ENABLED, false),
            overlayBubble = p.getBoolean(K_BUBBLE, false),
            bubbleX = p.getInt(K_BUBBLE_X, -1),
            bubbleY = p.getInt(K_BUBBLE_Y, -1),
            recents = decodeRecents(p.getString(K_RECENTS, null))
        )
    }

    /** Saves and announces the change. [event] null = silent save (e.g. bubble drag). */
    fun save(context: Context, state: AppState, event: StateHub.Event? = null) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply {
            putString(K_VIDEO_URI, state.videoUri?.toString())
            putString(K_VIDEO_NAME, state.videoName)
            putString(K_IMAGE_URI, state.imageUri?.toString())
            putString(K_IMAGE_NAME, state.imageName)
            putString(K_KIND, state.activeKind.name)
            putBoolean(K_ENABLED, state.enabled)
            putBoolean(K_BUBBLE, state.overlayBubble)
            putInt(K_BUBBLE_X, state.bubbleX)
            putInt(K_BUBBLE_Y, state.bubbleY)
            putString(K_RECENTS, encodeRecents(state.recents))
            apply()
        }
        if (event != null) StateHub.post(event)
    }

    /** Records a pick: takes the persistable grant, saves, announces. */
    fun pick(context: Context, uri: Uri, kind: MediaKind, name: String): AppState {
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: SecurityException) {
            // Photo-picker URIs do not always support persistable grants; the URI
            // still works for this process and is re-picked after a reboot.
        }
        val next = load(context).withPicked(uri, kind, name)
        save(context, next, StateHub.Event.MEDIA)
        return next
    }

    fun setEnabled(context: Context, enabled: Boolean): AppState {
        val next = load(context).withEnabled(enabled)
        save(context, next, StateHub.Event.ENABLED)
        return next
    }

    fun setActiveKind(context: Context, kind: MediaKind): AppState {
        val next = load(context).withActiveKind(kind)
        save(context, next, StateHub.Event.MEDIA)
        return next
    }

    fun setBubbleVisible(context: Context, visible: Boolean): AppState {
        val next = load(context).withBubbleVisible(visible)
        save(context, next, StateHub.Event.META)
        return next
    }

    fun setBubblePosition(context: Context, x: Int, y: Int) {
        save(context, load(context).withBubblePosition(x, y), event = null)
    }

    fun removeRecent(context: Context, uri: Uri): AppState {
        val next = load(context).withoutRecent(uri)
        save(context, next, StateHub.Event.META)
        return next
    }

    /** True when the file behind [uri] can still be opened. */
    fun canRead(context: Context, uri: Uri): Boolean {
        if (MediaRepository.canRead(context, uri)) return true
        return runCatching {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
        }.getOrDefault(false)
    }

    private fun encodeRecents(recents: List<RecentMedia>): String =
        recents.joinToString(RECENT_SEP) {
            listOf(it.uri.toString(), it.kind.name, it.name.replace(FIELD_SEP, " "))
                .joinToString(FIELD_SEP)
        }

    private fun decodeRecents(raw: String?): List<RecentMedia> {
        if (raw.isNullOrEmpty()) return emptyList()
        return raw.split(RECENT_SEP).mapNotNull { entry ->
            val parts = entry.split(FIELD_SEP)
            if (parts.size < 3) return@mapNotNull null
            runCatching {
                RecentMedia(Uri.parse(parts[0]), MediaKind.valueOf(parts[1]), parts[2])
            }.getOrNull()
        }
    }
}
