package com.teamily.virtualcamera

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.teamily.virtualcamera.camera.FrameBus
import com.teamily.virtualcamera.camera.SurfaceFrameWriter
import com.teamily.virtualcamera.data.AppStateStore
import com.teamily.virtualcamera.databinding.ActivityCameraIntentBinding
import com.teamily.virtualcamera.media.MediaEngine
import com.teamily.virtualcamera.util.MediaFiles
import java.io.File
import java.io.FileOutputStream

/**
 * The "default camera app" entry point.
 *
 * When this app is the system's default camera, every `IMAGE_CAPTURE` /
 * `STILL_IMAGE_CAMERA` / `VIDEO_CAMERA` / `VIDEO_CAPTURE` request from another app
 * lands here instead of the stock camera. We show the user's chosen media as the
 * live viewfinder, and when the caller asks for a capture we return a frame from
 * that media — so the receiving app genuinely gets "a picture from the camera",
 * it is just not the physical sensor.
 *
 * This is the honest, no-root path. It works only when the caller goes through the
 * camera *intent* API (or when this app is the default camera and the caller uses
 * the system camera shortcut). An app that opens `CameraManager` directly and
 * expects a real `CameraDevice` cannot be served without root / a HAL — see README.
 */
class CameraIntentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCameraIntentBinding
    private var engine: MediaEngine? = null
    private var writer: SurfaceFrameWriter? = null
    private var mode: Mode = Mode.STILL
    private var outputUri: Uri? = null
    private var captured = false

    private enum class Mode { STILL, VIDEO, VIEWFINDER_ONLY }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraIntentBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        mode = resolveMode(intent)
        outputUri = resolveOutputUri(intent)

        val selection = AppStateStore.load(this).active
        if (selection == null) {
            // Nothing chosen yet: send the user to the picker, then come back.
            Toast.makeText(this, R.string.camera_intent_no_media, Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        binding.cameraIntentLabel.text = when (mode) {
            Mode.STILL -> getString(R.string.camera_intent_still, selection.displayName)
            Mode.VIDEO -> getString(R.string.camera_intent_video, selection.displayName)
            Mode.VIEWFINDER_ONLY -> getString(R.string.camera_intent_viewfinder, selection.displayName)
        }

        binding.captureButton.visibility =
            if (mode == Mode.VIEWFINDER_ONLY) View.GONE else View.VISIBLE
        binding.captureButton.setOnClickListener { performCapture() }
        binding.cancelButton.setOnClickListener { finishCancelled() }

        // The viewfinder is driven by the real engine output, so what you see is
        // exactly what gets captured / streamed. The engine is started regardless of
        // the bubble's on/off switch: a caller that explicitly asked for a camera
        // should get a picture, not a black frame.
        engine = MediaEngine(applicationContext).also { eng ->
            eng.onFrame = { }
            eng.start(selection)
        }

        binding.cameraSurface.holder.addCallback(object : android.view.SurfaceHolder.Callback {
            override fun surfaceCreated(holder: android.view.SurfaceHolder) {
                startWriter(holder)
            }

            override fun surfaceChanged(
                holder: android.view.SurfaceHolder,
                format: Int,
                width: Int,
                height: Int
            ) {
                writer?.stop()
                startWriter(holder)
            }

            override fun surfaceDestroyed(holder: android.view.SurfaceHolder) {
                writer?.stop()
                writer = null
            }
        })
    }

    private fun startWriter(holder: android.view.SurfaceHolder) {
        val w = SurfaceFrameWriter(
            target = holder.surface,
            width = (holder.surfaceFrame?.width() ?: 1280).coerceAtLeast(2),
            height = (holder.surfaceFrame?.height() ?: 720).coerceAtLeast(2),
            fps = 30,
            label = "CameraIntentWriter"
        )
        writer = w
        w.start()
    }

    // ------------------------------------------------------------------ capture

    private fun performCapture() {
        if (captured) return
        captured = true

        val frame = FrameBus.latest()
        if (frame == null) {
            Toast.makeText(this, R.string.camera_intent_no_frame, Toast.LENGTH_SHORT).show()
            captured = false
            return
        }

        val bitmap = frame.copy(Bitmap.Config.ARGB_8888, false)

        // 1) Caller supplied EXTRA_OUTPUT → write the frame there.
        val target = outputUri
        if (target != null) {
            val ok = runCatching {
                contentResolver.openOutputStream(target)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                } != null
            }.getOrDefault(false)

            if (!ok) {
                Toast.makeText(this, R.string.camera_intent_write_failed, Toast.LENGTH_SHORT).show()
                captured = false
                return
            }
            setResult(Activity.RESULT_OK)
        } else {
            // 2) No EXTRA_OUTPUT → return the bitmap as a thumbnail (the documented
            //    IMAGE_CAPTURE contract) plus a content URI where possible.
            val uri = saveToCacheAndShare(bitmap)
            setResult(
                Activity.RESULT_OK,
                Intent().apply {
                    putExtra("data", bitmap)
                    uri?.let { putExtra(MediaStore.EXTRA_OUTPUT, it); data = it }
                }
            )
        }

        bitmap.recycle()
        binding.captureFlash.alpha = 1f
        binding.captureFlash.animate().alpha(0f).setDuration(220).start()

        // Give the caller a moment, then get out of the way.
        binding.cameraSurface.postDelayed({ finish() }, 260)
    }

    private fun saveToCacheAndShare(bitmap: Bitmap): Uri? = runCatching {
        val dir = File(cacheDir, "captures").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        androidx.core.content.FileProvider.getUriForFile(
            this, "$packageName.fileprovider", file
        )
    }.getOrNull()

    private fun finishCancelled() {
        setResult(Activity.RESULT_CANCELED)
        finish()
    }

    override fun onDestroy() {
        writer?.stop()
        writer = null
        engine?.release()
        engine = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ intents

    private fun resolveMode(intent: Intent?): Mode = when (intent?.action) {
        MediaStore.ACTION_IMAGE_CAPTURE,
        MediaStore.ACTION_IMAGE_CAPTURE_SECURE -> Mode.STILL
        MediaStore.ACTION_VIDEO_CAPTURE -> Mode.VIDEO
        "android.media.action.STILL_IMAGE_CAMERA",
        "android.media.action.STILL_IMAGE_CAMERA_SECURE",
        "android.media.action.VIDEO_CAMERA" -> Mode.VIEWFINDER_ONLY
        else -> Mode.STILL
    }

    private fun resolveOutputUri(intent: Intent?): Uri? {
        if (intent == null) return null
        return if (android.os.Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(MediaStore.EXTRA_OUTPUT, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(MediaStore.EXTRA_OUTPUT)
        }
    }
}
