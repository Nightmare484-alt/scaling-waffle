package com.teamily.virtualcamera

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.teamily.virtualcamera.databinding.ActivityGuideBinding

/**
 * "How to use with YouTube Live" — the honest guide.
 *
 * Three paths, in order of how well they actually work on a stock phone:
 *
 *  1. **Screencast** (works today, no root). YouTube's Android app has a
 *     "Screencast" option that streams the phone's *screen*. We render the media
 *     fullscreen in [ScreenFeedActivity] and the user screencasts that. This is the
 *     only path that puts the media into a real YouTube live stream without root.
 *  2. **Default camera app** (works for apps that use the camera *intent*). YouTube's
 *     own in-app camera does not, so this path is for other apps — documented so the
 *     user knows why it does not help here.
 *  3. **Root / LSPosed / virtual-camera HAL** (the only way to truly replace the
 *     camera for YouTube's in-app camera).
 *
 * The screen says all of this plainly rather than implying path 2 will fix YouTube.
 */
class GuideActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGuideBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGuideBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.guideClose.setOnClickListener { finish() }

        binding.guideStartScreencast.setOnClickListener {
            startActivity(Intent(this, ScreenFeedActivity::class.java))
        }

        binding.guideOpenCameraSettings.setOnClickListener {
            openDefaultAppsSettings()
        }
    }

    /**
     * Tries the OEM default-apps screen, then the app's own settings page.
     *
     * There is no public API to set the default camera app — the user must do it in
     * Settings. We can only deep-link as close as the OEM allows.
     */
    private fun openDefaultAppsSettings() {
        val candidates = listOf(
            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(
                Uri.parse("package:$packageName")
            ),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (intent in candidates) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (runCatching { startActivity(intent) }.isSuccess) return
        }
        Toast.makeText(this, R.string.guide_settings_unavailable, Toast.LENGTH_SHORT).show()
    }
}
