package com.teamily.virtualcamera.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.teamily.virtualcamera.MainActivity
import com.teamily.virtualcamera.R
import com.teamily.virtualcamera.camera.FrameBus
import com.teamily.virtualcamera.camera.VirtualCameraDevice
import com.teamily.virtualcamera.camera.VirtualCameraProvider
import com.teamily.virtualcamera.data.AppState
import com.teamily.virtualcamera.data.AppStateStore
import com.teamily.virtualcamera.data.FrameStyle
import com.teamily.virtualcamera.data.FrameStyleStore
import com.teamily.virtualcamera.data.MediaKind
import com.teamily.virtualcamera.data.MediaSelection
import com.teamily.virtualcamera.data.StateHub
import com.teamily.virtualcamera.media.MediaEngine
import com.teamily.virtualcamera.overlay.BubbleOverlay
import com.teamily.virtualcamera.projection.ScreenCaptureSource

/**
 * The one owner of everything that has to outlive an Activity.
 *
 * Responsibilities:
 *  1. Run [MediaEngine] so frames keep being decoded into [FrameBus] while the user
 *     is in another app (YouTube, Zoom, TikTok…).
 *  2. Host the Camera2-shaped [VirtualCameraDevice] and expose it to in-process
 *     consumers (the camera-intent activity, a privileged bridge, an encoder).
 *  3. Own the [ScreenCaptureSource] fallback, because on Android 14+ a MediaProjection
 *     must be started from a running foreground service.
 *  4. Own the floating [BubbleOverlay] — the draggable control bubble. It lives here,
 *     not in an Activity, precisely so it stays on top while YouTube is in front and
 *     survives the user switching apps.
 *
 * Declared with `foregroundServiceType="camera|mediaProjection"` — both types are
 * needed depending on which path the user turned on.
 *
 * ## State
 * All user-visible state (which media, on/off, layout, bubble position) lives in
 * [AppStateStore] / [FrameStyleStore]. This service is a *reader* of that state plus
 * the thing that acts on it, which is what makes the bubble, the main screen and the
 * camera-intent activity agree without talking to each other.
 */
class VirtualCameraService : Service() {

    companion object {
        private const val TAG = "VirtualCameraService"
        private const val CHANNEL_ID = "virtual_camera_running"
        private const val NOTIFICATION_ID = 4242

        const val ACTION_START = "com.teamily.virtualcamera.START"
        const val ACTION_STOP = "com.teamily.virtualcamera.STOP"
        const val ACTION_START_PROJECTION = "com.teamily.virtualcamera.START_PROJECTION"
        const val ACTION_STOP_PROJECTION = "com.teamily.virtualcamera.STOP_PROJECTION"
        const val ACTION_SET_ENABLED = "com.teamily.virtualcamera.SET_ENABLED"
        const val ACTION_RELOAD_MEDIA = "com.teamily.virtualcamera.RELOAD_MEDIA"
        const val ACTION_SHOW_BUBBLE = "com.teamily.virtualcamera.SHOW_BUBBLE"
        const val ACTION_HIDE_BUBBLE = "com.teamily.virtualcamera.HIDE_BUBBLE"

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_FPS = "fps"
        const val EXTRA_ENABLED = "enabled"

        /** True while [VirtualCameraService] is alive. */
        @Volatile
        var isRunning: Boolean = false
            private set

        /** Convenience for UI code that just wants the service up. */
        fun start(context: Context, action: String = ACTION_START) {
            val intent = Intent(context, VirtualCameraService::class.java).setAction(action)
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    inner class LocalBinder : Binder() {
        fun service(): VirtualCameraService = this@VirtualCameraService
    }

    private val binder = LocalBinder()
    private val main = Handler(android.os.Looper.getMainLooper())

    private var engine: MediaEngine? = null
    private var projection: ScreenCaptureSource? = null
    private var bubble: BubbleOverlay? = null

    /** Handle to the Camera2-shaped device this service exposes to callers. */
    var virtualDevice: VirtualCameraDevice? = null
        private set

    var statusText: String = "Idle"
        private set

    /** Mirrors [AppState.enabled] — the bubble's big switch. */
    var feedEnabled: Boolean = false
        private set

    private val statusListeners = mutableSetOf<(String) -> Unit>()

    private val stateListener = StateHub.Listener { event ->
        when (event) {
            StateHub.Event.MEDIA -> reloadMedia()
            StateHub.Event.ENABLED -> applyEnabledState()
            StateHub.Event.STYLE -> applyStyle()
            StateHub.Event.META -> Unit
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createChannel()
        isRunning = true

        FrameBus.style = FrameStyleStore.load(this)

        engine = MediaEngine(applicationContext).also { eng ->
            eng.onStateChanged = { state, message ->
                statusText = when (state) {
                    MediaEngine.State.PLAYING -> message ?: "Virtual camera running"
                    MediaEngine.State.PREPARING -> "Preparing media…"
                    MediaEngine.State.PAUSED -> message ?: "Virtual camera off"
                    MediaEngine.State.ERROR -> message ?: "Error"
                    MediaEngine.State.IDLE -> "Idle"
                }
                publishStatus()
                updateNotification()
            }
        }
        projection = ScreenCaptureSource(applicationContext).also { p ->
            p.onStatus = { msg ->
                statusText = msg
                publishStatus()
                updateNotification()
            }
        }

        StateHub.addListener(stateListener)

        // Restore the bubble if the user had it on when the process died.
        if (AppStateStore.load(this).overlayBubble) {
            main.post { showBubble() }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdownEverything()
                return START_NOT_STICKY
            }

            ACTION_SET_ENABLED -> {
                startForegroundSafely(includeProjection = projection?.isActive == true)
                val enabled = intent.getBooleanExtra(EXTRA_ENABLED, true)
                AppStateStore.setEnabled(this, enabled)
                return START_STICKY
            }

            ACTION_RELOAD_MEDIA -> {
                startForegroundSafely(includeProjection = projection?.isActive == true)
                reloadMedia()
                return START_STICKY
            }

            ACTION_SHOW_BUBBLE -> {
                startForegroundSafely(includeProjection = projection?.isActive == true)
                AppStateStore.setBubbleVisible(this, true)
                showBubble()
                return START_STICKY
            }

            ACTION_HIDE_BUBBLE -> {
                AppStateStore.setBubbleVisible(this, false)
                hideBubble()
                // If nothing else is running, let the service go.
                if (!feedEnabled && projection?.isActive != true) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
                return START_STICKY
            }

            ACTION_START_PROJECTION -> {
                startForegroundSafely(includeProjection = true)
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                val fps = intent.getIntExtra(EXTRA_FPS, 30)

                // On Android 14+ the projection must be started *after* the FGS is up
                // with the mediaProjection type, hence the post to the looper.
                main.post {
                    startMediaIfEnabled()
                    if (resultCode != -1 && data != null) {
                        projection?.start(resultCode, data, fps)
                    } else {
                        statusText = "Screen capture permission missing"
                        publishStatus()
                    }
                    updateNotification()
                }
                return START_STICKY
            }

            ACTION_STOP_PROJECTION -> {
                projection?.stop()
                statusText = if (engine?.isRunning == true) "Virtual camera running" else "Idle"
                publishStatus()
                updateNotification()
                return START_STICKY
            }

            else -> {
                startForegroundSafely(includeProjection = false)
                val state = AppStateStore.load(this)
                feedEnabled = state.enabled
                if (state.overlayBubble) showBubble()
                startMediaIfEnabled()
                openVirtualDevice()
                return START_STICKY
            }
        }
    }

    // ------------------------------------------------------------- media

    private fun startMediaIfEnabled() {
        val state = AppStateStore.load(this)
        feedEnabled = state.enabled
        if (!state.enabled) {
            statusText = "Virtual camera off — turn it on from the bubble"
            publishStatus()
            return
        }
        reloadMedia()
    }

    /** (Re)starts the engine on whatever media is currently active. */
    private fun reloadMedia() {
        val state = AppStateStore.load(this)
        feedEnabled = state.enabled
        val selection = state.active
        if (selection == null) {
            statusText = "No media selected yet"
            publishStatus()
            return
        }
        if (!AppStateStore.canRead(this, selection.uri)) {
            statusText = "Media permission lost — pick the file again"
            publishStatus()
            return
        }
        engine?.start(selection)
        engine?.setPaused(!state.enabled)
    }

    private fun applyEnabledState() {
        val state = AppStateStore.load(this)
        feedEnabled = state.enabled
        if (state.enabled) {
            if (engine?.isRunning != true) {
                reloadMedia()
            } else {
                engine?.setPaused(false)
            }
        } else {
            engine?.setPaused(true)
            statusText = "Virtual camera off"
            publishStatus()
        }
        updateNotification()
    }

    private fun applyStyle() {
        FrameBus.style = FrameStyleStore.load(this)
        // Re-compose from the *raw* frame, not the already-composed one — otherwise
        // the layout would be applied twice and the picture would jump.
        FrameBus.recompose()
    }

    /** Opens the Camera2-shaped virtual device so in-process consumers can attach. */
    private fun openVirtualDevice() {
        if (virtualDevice != null) return
        VirtualCameraProvider.openCamera(
            this,
            VirtualCameraProvider.BACK_CAMERA_ID,
            object : VirtualCameraProvider.DeviceStateCallback {
                override fun onOpened(device: VirtualCameraDevice) {
                    Log.d(TAG, "Virtual camera device opened")
                    virtualDevice = device
                    publishStatus()
                }

                override fun onDisconnected(device: VirtualCameraDevice) {
                    Log.d(TAG, "Virtual camera device disconnected")
                    virtualDevice = null
                }

                override fun onError(device: VirtualCameraDevice, error: Int) {
                    Log.e(TAG, "Virtual camera error $error")
                    virtualDevice = null
                }
            }
        )
    }

    // ------------------------------------------------------------- bubble

    fun showBubble() {
        if (bubble?.isShowing == true) return
        val overlay = bubble ?: BubbleOverlay(this).also { bubble = it }
        val shown = overlay.show()
        if (!shown) {
            statusText = "Overlay permission needed — allow \"display over other apps\""
            publishStatus()
        }
    }

    fun hideBubble() {
        bubble?.hide()
    }

    val isBubbleShowing: Boolean get() = bubble?.isShowing == true

    /**
     * Drops the bubble instance entirely.
     *
     * [BubbleOverlay] holds a reference to this service as its Context, so keeping the
     * object around after the bubble is gone would leak the service. Called from
     * [onDestroy] and from the bubble's own "Stop & close".
     */
    fun releaseBubble() {
        bubble?.hide()
        bubble = null
    }

    // ------------------------------------------------------------- status

    fun addStatusListener(listener: (String) -> Unit) {
        statusListeners.add(listener)
        listener(statusText)
    }

    fun removeStatusListener(listener: (String) -> Unit) {
        statusListeners.remove(listener)
    }

    private fun publishStatus() {
        statusListeners.toList().forEach { runCatching { it(statusText) } }
    }

    fun setStatus(text: String) {
        statusText = text
        publishStatus()
        updateNotification()
    }

    /** Public API used by the bubble and the main screen. */
    fun setFeedEnabled(enabled: Boolean) {
        AppStateStore.setEnabled(this, enabled)
    }

    fun selectKind(kind: MediaKind) {
        AppStateStore.setActiveKind(this, kind)
    }

    fun applyStyle(style: FrameStyle) {
        FrameStyleStore.save(this, style)
    }

    fun currentState(): AppState = AppStateStore.load(this)

    fun currentSelection(): MediaSelection? = engine?.selection

    fun stopEverything() {
        shutdownEverything()
    }

    private fun shutdownEverything() {
        engine?.stop()
        projection?.stop()
        virtualDevice?.close()
        virtualDevice = null
        releaseBubble()
        FrameBus.clearFrame()
        AppStateStore.setEnabled(this, false)
        statusText = "Idle"
        publishStatus()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        isRunning = false
        StateHub.removeListener(stateListener)
        engine?.release()
        engine = null
        projection?.stop()
        projection = null
        virtualDevice?.close()
        virtualDevice = null
        releaseBubble()
        FrameBus.clearFrame()
        super.onDestroy()
    }

    // -------------------------------------------------------- notification

    private fun startForegroundSafely(includeProjection: Boolean) {
        isRunning = true
        val notification = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val types = if (includeProjection) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                }
                startForeground(NOTIFICATION_ID, notification, types)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            // Android 14 throws if the camera/projection type is used without the
            // corresponding runtime grant; fall back to a plain FGS so the service
            // at least keeps the media loop and the bubble alive.
            Log.w(TAG, "Typed foreground start failed, falling back", e)
            runCatching { startForeground(NOTIFICATION_ID, notification) }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, VirtualCameraService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_camera)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(statusText)
            .setContentIntent(openApp)
            .addAction(0, getString(R.string.action_stop), stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification() {
        if (!isRunning) return
        runCatching {
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIFICATION_ID, buildNotification())
        }
    }
}
