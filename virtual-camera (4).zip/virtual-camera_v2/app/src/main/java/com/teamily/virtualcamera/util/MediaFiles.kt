package com.teamily.virtualcamera.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri

/** Bitmap / frame helpers shared by the preview screen and the camera-intent path. */
object MediaFiles {

    /**
     * Decodes an image URI, downsampled so the longest edge is at most [maxDim].
     * Two passes (bounds, then sampled decode) keep memory low on large photos.
     */
    fun decodeBitmap(context: Context, uri: Uri, maxDim: Int = 1920): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        runCatching {
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        var longest = maxOf(bounds.outWidth, bounds.outHeight)
        while (longest / sample > maxDim) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
        }.getOrNull()
    }

    /**
     * Grabs a representative frame from a video — the first key frame at or
     * before [timeUs]. Used when another app asks us for a still photo while a
     * video is loaded, and for the picker thumbnail.
     */
    fun videoFrame(context: Context, uri: Uri, timeUs: Long = 0L): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    /**
     * Picks the read-back buffer size for a video: the source aspect at most
     * [maxEdge] on the long side.
     *
     * Returned as a `Pair(width, height)`. Falls back to [fallbackW] x [fallbackH]
     * when the metadata has no usable dimensions, so playback still starts.
     *
     * Keeping the *source* aspect here is what allows FrameBus.style to offer a real
     * Fit / Fill / Stretch choice later — cropping at decode time would bake one
     * choice in permanently.
     */
    fun videoReadbackSize(
        context: Context,
        uri: Uri,
        maxEdge: Int,
        fallbackW: Int,
        fallbackH: Int
    ): Pair<Int, Int> {
        val retriever = MediaMetadataRetriever()
        val w: Int
        val h: Int
        try {
            retriever.setDataSource(context, uri)
            val rw = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 0
            val rh = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 0

            // Rotation metadata matters: a portrait clip records 1920x1080 + 90deg.
            val rotation = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                ?.toIntOrNull() ?: 0
            val swapped = rotation == 90 || rotation == 270

            if (rw <= 0 || rh <= 0) return fallbackW to fallbackH
            w = if (swapped) rh else rw
            h = if (swapped) rw else rh
        } catch (e: Exception) {
            return fallbackW to fallbackH
        } finally {
            runCatching { retriever.release() }
        }

        val longEdge = maxOf(w, h)
        if (longEdge <= maxEdge) {
            // Already small enough — round down to even numbers, which encoders want.
            return (w and 0x7FFFFFE).coerceAtLeast(2) to (h and 0x7FFFFFE).coerceAtLeast(2)
        }
        val scale = maxEdge.toFloat() / longEdge
        val outW = ((w * scale).toInt() and 0x7FFFFFE).coerceAtLeast(2)
        val outH = ((h * scale).toInt() and 0x7FFFFFE).coerceAtLeast(2)
        return outW to outH
    }

    /** Duration in milliseconds, or 0 when unknown. */
    fun videoDurationMs(context: Context, uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            runCatching { retriever.release() }
        }
    }

    /** Scales [source] to cover [width] x [height] and centers it (letterbox-free crop). */
    fun centerCrop(source: Bitmap, width: Int, height: Int): Bitmap {
        if (width <= 0 || height <= 0) return source
        val scale = maxOf(width.toFloat() / source.width, height.toFloat() / source.height)
        val scaledW = (source.width * scale).toInt().coerceAtLeast(1)
        val scaledH = (source.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(source, scaledW, scaledH, true)
        val x = ((scaledW - width) / 2).coerceAtLeast(0)
        val y = ((scaledH - height) / 2).coerceAtLeast(0)
        val cropped = Bitmap.createBitmap(scaled, x, y, minOf(width, scaledW), minOf(height, scaledH))
        if (cropped != scaled && !scaled.isRecycled) scaled.recycle()
        return cropped
    }
}
