package com.teamily.virtualcamera.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import com.teamily.virtualcamera.FrameEditorActivity
import com.teamily.virtualcamera.GuideActivity
import com.teamily.virtualcamera.MainActivity
import com.teamily.virtualcamera.R
import com.teamily.virtualcamera.data.AppState
import com.teamily.virtualcamera.data.AppStateStore
import com.teamily.virtualcamera.data.FrameStyleStore
import com.teamily.virtualcamera.data.MediaKind
import com.teamily.virtualcamera.data.RecentMedia
import com.teamily.virtualcamera.data.ScaleMode
import com.teamily.virtualcamera.data.StateHub
import com.teamily.virtualcamera.data.StyleMath
import com.teamily.virtualcamera.service.VirtualCameraService
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The draggable floating bubble and its control panel.
 *
 * ## Why a WindowManager overlay and not a floating Activity
 * A `TYPE_APPLICATION_OVERLAY` window is owned by the *service*, not by an Activity,
 * so it keeps drawing on top of YouTube / Zoom / TikTok while they are in the
 * foreground and it survives the user switching apps. An Activity would be pushed
 * behind the streaming app the moment it took focus — which is exactly the bug the
 * user hit (the real camera opening instead of the virtual one, with no way to
 * control anything).
 *
 * ## Touch handling
 * The bubble is a 56dp circle. A drag moves it; a tap (no movement beyond
 * [ViewConfiguration.getScaledTouchSlop]) expands the panel. The panel is a separate
 * window so it can be dismissed without moving the bubble, and it is
 * `FLAG_NOT_FOCUSABLE` so it never steals the keyboard from the app underneath.
 *
 * ## State
 * Every control writes through [AppStateStore] / [FrameStyleStore] and lets
 * [StateHub] notify the service. The panel never talks to the decoder directly, so it
 * cannot drift out of sync with the main screen or the camera-intent activity.
 */
class BubbleOverlay(private val context: Context) {

    companion object {
        private const val TAG = "BubbleOverlay"
        private const val BUBBLE_SIZE_DP = 56
        private const val PANEL_MARGIN_DP = 8
        private const val PANEL_WIDTH_DP = 300
        private const val PANEL_MAX_HEIGHT_DP = 520
    }

    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val inflater = LayoutInflater.from(context)
    private val density = context.resources.displayMetrics.density

    private var bubbleView: View? = null
    private var panelView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private var bubbleDot: View? = null
    private var bubbleRoot: FrameLayout? = null

    private var panelExpanded = false

    private val stateListener = StateHub.Listener { event ->
        when (event) {
            StateHub.Event.ENABLED, StateHub.Event.MEDIA, StateHub.Event.META -> {
                refreshBubbleAppearance()
                if (panelExpanded) refreshPanel()
            }
            StateHub.Event.STYLE -> if (panelExpanded) refreshPanel()
        }
    }

    val isShowing: Boolean get() = bubbleView != null

    // ------------------------------------------------------------------ show

    /** Adds the bubble. Returns false when the overlay permission is missing. */
    fun show(): Boolean {
        if (bubbleView != null) return true
        if (!canDrawOverlays()) {
            Log.w(TAG, "SYSTEM_ALERT_WINDOW not granted")
            return false
        }

        val view = inflater.inflate(R.layout.overlay_bubble, null) as FrameLayout
        bubbleRoot = view
        bubbleDot = view.findViewById(R.id.bubbleDot)

        val state = AppStateStore.load(context)
        val params = WindowManager.LayoutParams(
            dp(BUBBLE_SIZE_DP),
            dp(BUBBLE_SIZE_DP),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (state.bubbleX >= 0) state.bubbleX else defaultX()
            y = if (state.bubbleY >= 0) state.bubbleY else defaultY()
        }

        attachDragHandler(view, params)

        return try {
            windowManager.addView(view, params)
            bubbleView = view
            bubbleParams = params
            StateHub.addListener(stateListener)
            refreshBubbleAppearance()
            true
        } catch (e: Exception) {
            Log.e(TAG, "addView failed", e)
            bubbleView = null
            false
        }
    }

    fun hide() {
        collapsePanel()
        StateHub.removeListener(stateListener)
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        bubbleView = null
        bubbleParams = null
        bubbleRoot = null
        bubbleDot = null
    }

    // ------------------------------------------------------------- dragging

    @SuppressLint("ClickableViewAccessibility")
    private fun attachDragHandler(view: View, params: WindowManager.LayoutParams) {
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false

        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    dragging = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) {
                        dragging = true
                        // Dragging the bubble dismisses the panel: it is anchored to
                        // the bubble and would otherwise float in the wrong place.
                        collapsePanel()
                    }
                    if (dragging) {
                        params.x = (startX + dx).roundToInt()
                        params.y = (startY + dy).roundToInt()
                        clampToScreen(params)
                        runCatching { windowManager.updateViewLayout(view, params) }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (dragging) {
                        // Persist where the user parked it, so it comes back there.
                        AppStateStore.setBubblePosition(context, params.x, params.y)
                    } else {
                        togglePanel()
                    }
                    true
                }

                MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        AppStateStore.setBubblePosition(context, params.x, params.y)
                    }
                    true
                }

                else -> false
            }
        }
    }

    private fun clampToScreen(params: WindowManager.LayoutParams) {
        val metrics = context.resources.displayMetrics
        val maxX = metrics.widthPixels - dp(BUBBLE_SIZE_DP)
        val maxY = metrics.heightPixels - dp(BUBBLE_SIZE_DP)
        params.x = params.x.coerceIn(0, maxX.coerceAtLeast(0))
        params.y = params.y.coerceIn(0, maxY.coerceAtLeast(0))
    }

    private fun defaultX(): Int {
        val metrics = context.resources.displayMetrics
        return metrics.widthPixels - dp(BUBBLE_SIZE_DP) - dp(12)
    }

    private fun defaultY(): Int {
        val metrics = context.resources.displayMetrics
        return (metrics.heightPixels * 0.35f).roundToInt()
    }

    // ---------------------------------------------------------------- panel

    private fun togglePanel() {
        if (panelExpanded) collapsePanel() else expandPanel()
    }

    private fun expandPanel() {
        if (panelExpanded) return
        val params = bubbleParams ?: return

        val panel = inflater.inflate(R.layout.overlay_panel, null)
        val panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Place the panel next to the bubble, flipping side when the bubble is
            // near the right edge so the panel never runs off screen.
            val metrics = context.resources.displayMetrics
            val panelWidth = dp(PANEL_WIDTH_DP)
            val spaceRight = metrics.widthPixels - (params.x + dp(BUBBLE_SIZE_DP))
            x = if (spaceRight >= panelWidth + dp(PANEL_MARGIN_DP)) {
                params.x + dp(BUBBLE_SIZE_DP) + dp(PANEL_MARGIN_DP)
            } else {
                (params.x - panelWidth - dp(PANEL_MARGIN_DP)).coerceAtLeast(dp(PANEL_MARGIN_DP))
            }
            y = params.y.coerceAtMost(
                (metrics.heightPixels - dp(PANEL_MAX_HEIGHT_DP))
                    .coerceAtLeast(dp(PANEL_MARGIN_DP))
            )
        }

        try {
            windowManager.addView(panel, panelLp)
        } catch (e: Exception) {
            Log.e(TAG, "panel addView failed", e)
            return
        }

        panelView = panel
        panelExpanded = true

        bindPanel(panel)
        refreshPanel()
    }

    private fun collapsePanel() {
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
        panelExpanded = false
    }

    // ------------------------------------------------------------ panel bind

    private fun bindPanel(panel: View) {
        panel.findViewById<View>(R.id.panelClose).setOnClickListener { collapsePanel() }

        panel.findViewById<View>(R.id.stopOverlay).setOnClickListener {
            AppStateStore.setEnabled(context, false)
            AppStateStore.setBubbleVisible(context, false)
            // Ask the service to tear everything down; it also drops this overlay
            // instance, which is what releases the service reference we hold.
            VirtualCameraService.start(context, VirtualCameraService.ACTION_STOP)
            hide()
        }

        panel.findViewById<View>(R.id.openGuide).setOnClickListener {
            collapsePanel()
            launchActivity(GuideActivity::class.java)
        }

        panel.findViewById<View>(R.id.openEditor).setOnClickListener {
            collapsePanel()
            launchActivity(FrameEditorActivity::class.java)
        }

        // ---- on/off switch
        val feedSwitch = panel.findViewById<Switch>(R.id.feedSwitch)
        feedSwitch.setOnCheckedChangeListener { _, checked ->
            AppStateStore.setEnabled(context, checked)
            VirtualCameraService.start(context, VirtualCameraService.ACTION_SET_ENABLED)
        }

        // ---- media kind chips
        panel.findViewById<View>(R.id.chipVideo).setOnClickListener {
            AppStateStore.setActiveKind(context, MediaKind.VIDEO)
        }
        panel.findViewById<View>(R.id.chipImage).setOnClickListener {
            AppStateStore.setActiveKind(context, MediaKind.IMAGE)
        }

        // ---- pickers. The picker needs an Activity, so we hand off to MainActivity
        //      with an extra telling it which picker to open on launch.
        panel.findViewById<View>(R.id.pickVideoBtn).setOnClickListener {
            collapsePanel()
            launchPicker(MediaKind.VIDEO)
        }
        panel.findViewById<View>(R.id.pickImageBtn).setOnClickListener {
            collapsePanel()
            launchPicker(MediaKind.IMAGE)
        }

        // ---- scale mode chips
        panel.findViewById<View>(R.id.modeFit).setOnClickListener { setMode(ScaleMode.FIT) }
        panel.findViewById<View>(R.id.modeFill).setOnClickListener { setMode(ScaleMode.FILL) }
        panel.findViewById<View>(R.id.modeStretch).setOnClickListener { setMode(ScaleMode.STRETCH) }
        panel.findViewById<View>(R.id.modeFree).setOnClickListener { setMode(ScaleMode.FREE) }

        // ---- zoom slider
        val zoom = panel.findViewById<SeekBar>(R.id.zoomSlider)
        val zoomValue = panel.findViewById<TextView>(R.id.zoomValue)
        zoom.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val value = StyleMath.fromPercent(progress)
                zoomValue.text = "${StyleMath.percent(value)}%"
                FrameStyleStore.save(context, FrameStyleStore.load(context).copy(zoom = value))
            }

            override fun onStartTrackingTouch(bar: SeekBar?) = Unit
            override fun onStopTrackingTouch(bar: SeekBar?) = Unit
        })

        // ---- position pad
        bindPositionPad(panel)
    }

    /**
     * The position pad: drag the dot to move the media inside the frame.
     *
     * The pad is a miniature of the output frame, so the dot's position maps directly
     * to [com.teamily.virtualcamera.data.FrameStyle.offsetX] / `offsetY` in -1..1.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun bindPositionPad(panel: View) {
        val pad = panel.findViewById<FrameLayout>(R.id.positionPad)
        val dot = panel.findViewById<View>(R.id.positionDot)

        fun applyFromTouch(x: Float, y: Float) {
            val w = pad.width.toFloat().coerceAtLeast(1f)
            val h = pad.height.toFloat().coerceAtLeast(1f)
            val nx = (x / w).coerceIn(0f, 1f)
            val ny = (y / h).coerceIn(0f, 1f)

            // Dot follows the finger, clamped inside the pad.
            dot.translationX = (nx - 0.5f) * (w - dot.width)
            dot.translationY = (ny - 0.5f) * (h - dot.height)

            val style = FrameStyleStore.load(context).copy(
                offsetX = ((nx - 0.5f) * 2f).coerceIn(-1f, 1f),
                offsetY = ((ny - 0.5f) * 2f).coerceIn(-1f, 1f)
            )
            FrameStyleStore.save(context, style)
        }

        pad.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    applyFromTouch(event.x, event.y)
                    true
                }
                MotionEvent.ACTION_UP -> true
                else -> false
            }
        }
    }

    private fun setMode(mode: ScaleMode) {
        val current = FrameStyleStore.load(context)
        // Switching to FREE seeds the free rect from the current layout so the
        // picture does not jump when the user starts dragging handles.
        val next = if (mode == ScaleMode.FREE && current.mode != ScaleMode.FREE) {
            current.copy(mode = ScaleMode.FREE, scaleX = 1f, scaleY = 1f)
        } else {
            current.copy(mode = mode)
        }
        FrameStyleStore.save(context, next)
    }

    // ---------------------------------------------------------------- refresh

    private fun refreshBubbleAppearance() {
        val state = AppStateStore.load(context)
        val on = state.enabled
        bubbleRoot?.setBackgroundResource(
            if (on) R.drawable.bg_bubble else R.drawable.bg_bubble_off
        )
        bubbleDot?.setBackgroundResource(
            if (on) R.drawable.bg_dot_on else R.drawable.bg_dot_off
        )
    }

    private fun refreshPanel() {
        val panel = panelView ?: return
        val state = AppStateStore.load(context)
        val style = FrameStyleStore.load(context)

        // ---- on/off
        val feedSwitch = panel.findViewById<Switch>(R.id.feedSwitch)
        if (feedSwitch.isChecked != state.enabled) {
            feedSwitch.setOnCheckedChangeListener(null)
            feedSwitch.isChecked = state.enabled
            feedSwitch.setOnCheckedChangeListener { _, checked ->
                AppStateStore.setEnabled(context, checked)
                VirtualCameraService.start(context, VirtualCameraService.ACTION_SET_ENABLED)
            }
        }
        feedSwitch.trackDrawable = context.getDrawable(
            if (state.enabled) R.drawable.bg_switch_track_on else R.drawable.bg_switch_track_off
        )
        panel.findViewById<TextView>(R.id.feedStateLabel).text = context.getString(
            if (state.enabled) R.string.feed_on else R.string.feed_off
        )
        panel.findViewById<TextView>(R.id.feedStateHint).text = context.getString(
            if (state.enabled) R.string.feed_on_hint else R.string.feed_off_hint
        )

        // ---- current media
        val active = state.active
        panel.findViewById<TextView>(R.id.currentMediaName).text =
            active?.displayName ?: context.getString(R.string.no_media_selected)

        // ---- kind chips
        val chipVideo = panel.findViewById<TextView>(R.id.chipVideo)
        val chipImage = panel.findViewById<TextView>(R.id.chipImage)
        chipVideo.isSelected = state.activeKind == MediaKind.VIDEO
        chipImage.isSelected = state.activeKind == MediaKind.IMAGE
        chipVideo.alpha = if (state.videoUri != null) 1f else 0.4f
        chipImage.alpha = if (state.imageUri != null) 1f else 0.4f

        // ---- recents
        bindRecents(panel, state)

        // ---- mode chips
        panel.findViewById<TextView>(R.id.modeFit).isSelected = style.mode == ScaleMode.FIT
        panel.findViewById<TextView>(R.id.modeFill).isSelected = style.mode == ScaleMode.FILL
        panel.findViewById<TextView>(R.id.modeStretch).isSelected = style.mode == ScaleMode.STRETCH
        panel.findViewById<TextView>(R.id.modeFree).isSelected = style.mode == ScaleMode.FREE

        // ---- zoom
        val zoom = panel.findViewById<SeekBar>(R.id.zoomSlider)
        val target = StyleMath.percent(style.zoom)
        if (zoom.progress != target) zoom.progress = target
        panel.findViewById<TextView>(R.id.zoomValue).text = "$target%"

        // ---- position dot
        val pad = panel.findViewById<FrameLayout>(R.id.positionPad)
        val dot = panel.findViewById<View>(R.id.positionDot)
        pad.post {
            val w = pad.width.toFloat()
            val h = pad.height.toFloat()
            if (w > 0 && h > 0) {
                dot.translationX = style.offsetX.coerceIn(-1f, 1f) * (w - dot.width) / 2f
                dot.translationY = style.offsetY.coerceIn(-1f, 1f) * (h - dot.height) / 2f
            }
        }
    }

    private fun bindRecents(panel: View, state: AppState) {
        val strip = panel.findViewById<LinearLayout>(R.id.recentStrip)
        val empty = panel.findViewById<TextView>(R.id.recentEmpty)
        strip.removeAllViews()

        if (state.recents.isEmpty()) {
            empty.visibility = View.VISIBLE
            return
        }
        empty.visibility = View.GONE

        state.recents.forEach { recent ->
            strip.addView(buildRecentChip(recent))
        }
    }

    private fun buildRecentChip(recent: RecentMedia): View {
        val chip = TextView(context).apply {
            text = recent.name
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            setTextColor(context.getColor(R.color.text_primary))
            textSize = 11f
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_recent)
            val padH = dp(10)
            val padV = dp(7)
            setPadding(padH, padV, padH, padV)
            maxWidth = dp(150)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(6) }
        }

        chip.setOnClickListener {
            // Quick-switch: make this the active media of its kind and use it.
            AppStateStore.pick(context, recent.uri, recent.kind, recent.name)
            VirtualCameraService.start(context, VirtualCameraService.ACTION_RELOAD_MEDIA)
        }

        chip.setOnLongClickListener {
            AppStateStore.removeRecent(context, recent.uri)
            true
        }

        return chip
    }

    // ---------------------------------------------------------------- helpers

    private fun launchActivity(cls: Class<*>) {
        val intent = Intent(context, cls).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    private fun launchPicker(kind: MediaKind) {
        val intent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(MainActivity.EXTRA_OPEN_PICKER, kind.name)
        }
        runCatching { context.startActivity(intent) }
    }

    private fun canDrawOverlays(): Boolean =
        if (Build.VERSION.SDK_INT >= 23) Settings.canDrawOverlays(context) else true

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun dp(value: Int): Int = (value * density).roundToInt()
}
