package com.teamily.virtualcamera.camera

import android.graphics.Bitmap
import android.util.Log
import com.teamily.virtualcamera.data.FrameStyle
import com.teamily.virtualcamera.data.ScaleMode
import com.teamily.virtualcamera.render.FrameComposer
import java.util.concurrent.atomic.AtomicReference

/**
 * The single source of truth for "what a camera frame looks like right now".
 *
 * Producers (the video decoder / image loader) call [publish]; consumers either poll
 * [latest] or register an [OnFrameListener]. Every consumer — the in-app preview, the
 * Camera2-shaped [VirtualCameraDevice], the MediaProjection writer, the camera-intent
 * capture and the fullscreen screencast feed — reads from here, so what you see in
 * the preview is byte-for-byte what other apps receive.
 *
 * ## Where resizing happens
 * [style] is applied here, at the producer, via [FrameComposer]. That is deliberate:
 * the overlay's Fit/Fill/Stretch/Free controls, its zoom slider and the drag handles
 * must affect *every* output at once. If each consumer applied the style itself they
 * would drift apart (and the Camera2 surface, which is written by a GL thread that
 * never sees the style, could not honour it at all).
 *
 * ## Cost
 * The default style ([ScaleMode.FILL], zoom 1, no offset) is a no-op when the
 * decoder already renders at [FRAME_WIDTH] x [FRAME_HEIGHT], so normal use pays
 * nothing at all. A custom layout costs one `Canvas` blit per frame.
 *
 * Frames are shared: consumers must copy before mutating.
 */
object FrameBus {

    fun interface OnFrameListener {
        fun onFrame(frame: Bitmap)
    }

    /** Fixed output size. 720p is the honest ceiling of a CPU read-back pipeline. */
    const val FRAME_WIDTH = 1280
    const val FRAME_HEIGHT = 720

    private const val TAG = "FrameBus"

    private val current = AtomicReference<Bitmap?>(null)

    /**
     * The last frame as the producer published it, *before* [style] was applied.
     *
     * Kept so a style change can be re-composed without asking the decoder for a new
     * frame. Without it, dragging the zoom slider on a still image would do nothing
     * until the next 1-second re-publish tick, and re-composing the already-composed
     * frame would apply the layout twice.
     */
    private val lastRaw = AtomicReference<Bitmap?>(null)

    private val listeners = java.util.concurrent.CopyOnWriteArraySet<OnFrameListener>()

    /**
     * Retired frames waiting to be recycled.
     *
     * Consumers draw on their own threads (the GL writer, the projection writer, the
     * preview) and hold a reference to the frame they are mid-way through drawing.
     * Recycling the previous frame the instant a new one arrives would pull the pixels
     * out from under them — a `RuntimeException: Canvas: trying to use a recycled
     * bitmap` at 30 fps. So retired frames are recycled a moment later, once every
     * consumer has certainly finished with them.
     */
    private val recycler = android.os.Handler(android.os.Looper.getMainLooper())
    private const val RECYCLE_DELAY_MS = 250L

    @Volatile
    private var currentStyle: FrameStyle = FrameStyle()

    /** The layout applied to every published frame. Set from [FrameStyleStore] owners. */
    var style: FrameStyle
        get() = currentStyle
        set(value) {
            currentStyle = value
        }

    /** Publishes a new frame. Takes ownership of [frame]; do not recycle it. */
    fun publish(frame: Bitmap) {
        if (frame.isRecycled) return

        // Remember the raw frame so [recompose] can re-apply a new style later.
        val previousRaw = lastRaw.getAndSet(frame)
        if (previousRaw != null && previousRaw !== frame) retire(previousRaw)

        emit(frame)
    }

    /**
     * Re-applies the current [style] to the last raw frame.
     *
     * Called when the user changes Fit/Fill/Stretch/Free, zoom or position, so the
     * change is visible immediately — including on a still image, which otherwise only
     * re-publishes once a second.
     */
    fun recompose() {
        val raw = lastRaw.get() ?: return
        if (raw.isRecycled) return
        emit(raw)
    }

    private fun emit(raw: Bitmap) {
        // Compose only when the layout needs it — the plain path returns [raw].
        val composed = try {
            FrameComposer.compose(raw, currentStyle, FRAME_WIDTH, FRAME_HEIGHT)
        } catch (e: Exception) {
            Log.e(TAG, "compose failed", e)
            raw
        }

        val previous = current.getAndSet(composed)
        if (previous != null && previous !== composed) {
            retire(previous)
        }

        listeners.forEach { listener ->
            runCatching { listener.onFrame(composed) }
        }
    }

    fun latest(): Bitmap? = current.get()?.takeUnless { it.isRecycled }

    fun addListener(listener: OnFrameListener) {
        listeners.add(listener)
    }

    fun removeListener(listener: OnFrameListener) {
        listeners.remove(listener)
    }

    /** Drops the current frame (output goes black) without unsubscribing listeners. */
    fun clearFrame() {
        current.getAndSet(null)?.let { retire(it) }
        lastRaw.getAndSet(null)?.let { retire(it) }
    }

    /** Schedules a frame for recycling once consumers are certainly done with it. */
    private fun retire(frame: Bitmap) {
        if (frame.isRecycled) return
        recycler.postDelayed({
            if (!frame.isRecycled) runCatching { frame.recycle() }
        }, RECYCLE_DELAY_MS)
    }

    fun clear() {
        clearFrame()
        listeners.clear()
    }

    /** True when a producer is actively feeding frames. */
    val isLive: Boolean get() = latest() != null
}
