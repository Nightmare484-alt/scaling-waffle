package com.teamily.virtualcamera.data

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArraySet

/**
 * One tiny in-process event hub so the bubble, the main screen, the overlay panel,
 * the Camera2 device and the projection writer all react to the same state changes
 * without holding references to each other.
 *
 * Deliberately not LiveData / Flow: the bubble lives in a Service, the panel is a
 * WindowManager view with no lifecycle of its own, and the Camera2 device may be
 * driven from a HAL bridge later. A plain listener set works for all of them.
 *
 * Events are delivered on the main thread.
 */
object StateHub {

    enum class Event {
        /** A different media file was chosen (or the video/image toggle flipped). */
        MEDIA,

        /** The virtual camera was switched on or off. */
        ENABLED,

        /** Scale mode / zoom / position changed. */
        STYLE,

        /** Something worth re-reading from SharedPreferences (recent list, etc.). */
        META
    }

    fun interface Listener {
        fun onStateChanged(event: Event)
    }

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<Listener>()

    fun addListener(listener: Listener) {
        listeners.add(listener)
    }

    fun removeListener(listener: Listener) {
        listeners.remove(listener)
    }

    /** Fire-and-forget; safe from any thread. */
    fun post(event: Event) {
        main.post {
            listeners.toList().forEach { l -> runCatching { l.onStateChanged(event) } }
        }
    }
}
