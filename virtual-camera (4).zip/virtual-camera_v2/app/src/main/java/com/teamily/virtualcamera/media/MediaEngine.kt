package com.teamily.virtualcamera.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.teamily.virtualcamera.camera.FrameBus
import com.teamily.virtualcamera.data.MediaSelection
import com.teamily.virtualcamera.util.MediaFiles
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Decodes the selected media into [FrameBus].
 *
 * Two producers feed the same bus:
 *  - **Video** — ExoPlayer renders into an offscreen [SurfaceTexture]; every
 *    `onFrameAvailable` we copy the texture to a [Bitmap] via a small GL read-back so
 *    that *any* consumer (Camera2 device, the JPEG capture, MediaProjection) can use
 *    it without sharing a GL context. Looping is on, so the "camera" never goes black.
 *  - **Image** — decoded once and re-published on a slow tick, so consumers that only
 *    react to changes (and encoders that need periodic P-frames) still see a stream.
 *
 * ## Aspect handling
 * The read-back buffer is sized to the *video's own aspect ratio*, not forced to
 * 16:9. That keeps the frame uncropped, which is what lets [FrameBus.style] offer a
 * meaningful Fit / Fill / Stretch / Free choice — cropping here would bake in one
 * choice and make "Fit" impossible to honour.
 *
 * ## On/off gating
 * [setPaused] drops frames without tearing down the decoder, so the bubble's big
 * switch is instant in both directions: unpausing shows the frame that is already
 * decoded instead of restarting playback.
 *
 * Runs on its own thread + its own GL context, independent of the UI.
 */
class MediaEngine(private val context: Context) {

    companion object {
        private const val TAG = "MediaEngine"
        /** Longest edge of the read-back buffer. 1280 keeps 720p30 comfortable. */
        private const val MAX_EDGE = 1280
    }

    enum class State { IDLE, PREPARING, PLAYING, PAUSED, ERROR }

    var onStateChanged: ((State, String?) -> Unit)? = null
    var onFrame: ((Bitmap) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor { r ->
        Thread(r, "MediaEngine").apply { priority = Thread.NORM_PRIORITY + 1 }
    }

    private var player: ExoPlayer? = null
    private var surfaceTexture: SurfaceTexture? = null
    private var videoSurface: Surface? = null
    private var bitmapPublisher: BitmapPublisher? = null
    private val running = AtomicBoolean(false)
    private val paused = AtomicBoolean(false)
    private var current: MediaSelection? = null

    /** 1x1 black frame published when the feed is switched off. */
    private var blackFrame: Bitmap? = null

    val isRunning: Boolean get() = running.get()
    val isPaused: Boolean get() = paused.get()
    val selection: MediaSelection? get() = current

    /** Starts (or restarts) playback of [selection] into [FrameBus]. */
    fun start(selection: MediaSelection) {
        stopInternal(clearBus = false)
        current = selection
        running.set(true)
        paused.set(false)
        notify(State.PREPARING, null)

        if (selection.isVideo) startVideo(selection) else startImage(selection)
    }

    /**
     * Turns the emitted feed on or off without destroying the decoder.
     *
     * Off publishes one black frame so consumers show black instead of freezing on
     * the last picture — that is what a switched-off camera looks like.
     */
    fun setPaused(value: Boolean) {
        if (!running.get()) {
            paused.set(value)
            return
        }
        if (paused.get() == value) return
        paused.set(value)
        if (value) {
            FrameBus.clearFrame()
            notify(State.PAUSED, "Virtual camera off \u2014 media kept ready")
        } else {
            // Re-publish immediately so the output resumes without waiting a frame.
            val selection = current ?: return
            if (!selection.isVideo) republishImageImmediately()
            notify(State.PLAYING, "Virtual camera on")
        }
        syncPlayerState()
    }

    private fun syncPlayerState() {
        main.post {
            player?.playWhenReady = !paused.get()
        }
    }

    fun stop() {
        stopInternal(clearBus = true)
    }

    private fun stopInternal(clearBus: Boolean) {
        running.set(false)
        paused.set(false)
        // NOTE: `current` is deliberately NOT cleared here. [start] sets it
        // synchronously and then posts its setup to the main thread; this cleanup is
        // also posted, so it runs *after* that assignment. Nulling it here would wipe
        // the selection the caller just made and the engine would never restart.
        main.post {
            player?.let {
                runCatching { it.stop() }
                runCatching { it.release() }
            }
            player = null
            videoSurface?.release()
            videoSurface = null
            surfaceTexture?.release()
            surfaceTexture = null
            bitmapPublisher?.release()
            bitmapPublisher = null
            if (clearBus) FrameBus.clearFrame()
            notify(State.IDLE, null)
        }
    }

    // ---------------------------------------------------------------- video

    private fun startVideo(selection: MediaSelection) {
        main.post {
            try {
                // Size the read-back buffer to the video's real aspect so the frame we
                // publish is uncropped; FrameBus.style decides what to do with it.
                val (bufW, bufH) = MediaFiles.videoReadbackSize(
                    context, selection.uri, MAX_EDGE,
                    FrameBus.FRAME_WIDTH, FrameBus.FRAME_HEIGHT
                )

                val tex = SurfaceTexture(0).apply {
                    setDefaultBufferSize(bufW, bufH)
                }
                surfaceTexture = tex
                val surface = Surface(tex)
                videoSurface = surface

                val exo = ExoPlayer.Builder(context).build().apply {
                    setMediaItem(MediaItem.fromUri(selection.uri))
                    repeatMode = Player.REPEAT_MODE_ONE   // loop forever = "live camera"
                    volume = 0f                          // a camera has no audio out
                    playWhenReady = !paused.get()
                    setVideoSurface(surface)
                }
                player = exo

                exo.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        when (playbackState) {
                            Player.STATE_READY -> {
                                if (!paused.get()) {
                                    notify(State.PLAYING, "Video loop running")
                                }
                            }
                            Player.STATE_ENDED -> exo.seekTo(0)
                            else -> Unit
                        }
                    }

                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        Log.e(TAG, "Player error", error)
                        notify(State.ERROR, "Cannot play this video: ${error.errorCodeName}")
                    }
                })
                exo.prepare()

                startBitmapPump(tex, bufW, bufH)
            } catch (e: Exception) {
                Log.e(TAG, "startVideo failed", e)
                notify(State.ERROR, e.message)
            }
        }
    }

    /**
     * Copies each decoded video frame into a Bitmap and publishes it.
     *
     * A production build would keep everything on the GPU (share the EGL context
     * between ExoPlayer's SurfaceTexture and the consumer surface, or drive
     * MediaCodec straight into `eglCreateWindowSurface`). The read-back is what lets
     * one frame reach five different consumers, and it is honest about the 720p
     * ceiling that comes with `glReadPixels`.
     */
    private fun startBitmapPump(tex: SurfaceTexture, bufW: Int, bufH: Int) {
        val publisher = BitmapPublisher(
            surfaceTexture = tex,
            width = bufW,
            height = bufH,
            onBitmap = { bitmap ->
                if (running.get() && !paused.get()) {
                    FrameBus.publish(bitmap)
                    onFrame?.invoke(bitmap)
                } else {
                    // Feed is off: drop the frame rather than publishing it.
                    if (!bitmap.isRecycled) bitmap.recycle()
                }
            }
        )
        bitmapPublisher = publisher

        tex.setOnFrameAvailableListener({
            publisher.requestFrame()
        }, Handler(Looper.getMainLooper()))
    }

    // ---------------------------------------------------------------- image

    private var imageCache: Bitmap? = null

    private fun startImage(selection: MediaSelection) {
        worker.execute {
            try {
                val bitmap = MediaFiles.decodeBitmap(context, selection.uri, 1920)
                if (bitmap == null) {
                    notify(State.ERROR, "Could not decode this image")
                    return@execute
                }
                // A newer start() may have superseded this one while we were decoding.
                if (!running.get() || current !== selection) {
                    if (!bitmap.isRecycled) bitmap.recycle()
                    return@execute
                }
                imageCache?.let { if (!it.isRecycled) it.recycle() }
                imageCache = bitmap

                if (!paused.get()) {
                    FrameBus.publish(bitmap.copy(Bitmap.Config.ARGB_8888, false))
                    notify(State.PLAYING, "Image shown as live camera")
                }

                // Re-publish periodically: keeps encoders producing P-frames and makes
                // the stream look alive to consumers that time out on silence.
                while (running.get() && current === selection) {
                    Thread.sleep(1000L)
                    if (!running.get() || current !== selection) break
                    if (!paused.get()) {
                        val src = imageCache
                        if (src != null && !src.isRecycled) {
                            FrameBus.publish(src.copy(Bitmap.Config.ARGB_8888, false))
                        }
                    }
                }
            } catch (e: InterruptedException) {
                // Normal shutdown.
            } catch (e: Exception) {
                Log.e(TAG, "startImage failed", e)
                notify(State.ERROR, e.message)
            }
        }
    }

    private fun republishImageImmediately() {
        val src = imageCache ?: return
        if (src.isRecycled) return
        FrameBus.publish(src.copy(Bitmap.Config.ARGB_8888, false))
    }

    private fun notify(state: State, message: String?) {
        main.post { onStateChanged?.invoke(state, message) }
    }

    fun release() {
        stopInternal(clearBus = true)
        imageCache?.let { if (!it.isRecycled) it.recycle() }
        imageCache = null
        worker.shutdownNow()
    }
}
