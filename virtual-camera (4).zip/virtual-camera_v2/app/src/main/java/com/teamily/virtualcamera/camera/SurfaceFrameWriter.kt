package com.teamily.virtualcamera.camera

import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import com.teamily.virtualcamera.camera.gl.EglCore
import com.teamily.virtualcamera.camera.gl.TextureQuad
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Pumps [FrameBus] frames into an arbitrary [Surface] at a fixed rate.
 *
 * This is the piece that makes the app an actual *frame source*: hand it the Surface
 * of a SurfaceView, a MediaCodec encoder input, or a MediaProjection receiver, and
 * every frame the media producer publishes lands there. The same class is used by the
 * preview, the Camera2-shaped capture session, the MediaProjection fallback and the
 * fullscreen screencast window — one code path, four consumers.
 *
 * ## Geometry
 * Frames arrive from [FrameBus] already composed to [FrameBus.FRAME_WIDTH] x
 * [FrameBus.FRAME_HEIGHT] with the user's Fit/Fill/Stretch/Free layout baked in. So
 * the writer's job is a plain 1:1 blit — it must *not* crop again, or a "Fit" layout
 * would be silently turned back into a "Fill". The quad is therefore drawn in
 * stretch mode, and any bars come from the composition itself.
 *
 * @param width/height the destination size in pixels. SurfaceView-backed surfaces get
 *        their real size; encoder/projection surfaces are fixed at creation.
 */
class SurfaceFrameWriter(
    private val target: Surface,
    private val width: Int,
    private val height: Int,
    private val fps: Int = 30,
    private val label: String = "SurfaceFrameWriter"
) {

    interface Listener {
        fun onFirstFrameWritten()
        fun onWriterStopped()
    }

    var listener: Listener? = null

    private val running = AtomicBoolean(false)

    @Volatile
    private var thread: HandlerThread? = null

    fun start() {
        if (!running.compareAndSet(false, true)) return
        val t = HandlerThread(label).also { it.start() }
        thread = t
        Handler(t.looper).post { loop() }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        thread?.quitSafely()
        thread = null
    }

    private fun loop() {
        var core: EglCore? = null
        var eglSurface: android.opengl.EGLSurface? = null
        var quad: TextureQuad? = null
        try {
            core = EglCore()
            eglSurface = core.createWindowSurface(target)
            core.makeCurrent(eglSurface)

            quad = TextureQuad(external = false)
            quad.viewportAspect = width.toFloat() / height.toFloat()
            GLES20.glViewport(0, 0, width, height)

            val frameIntervalMs = (1000L / fps.coerceAtLeast(1)).coerceAtLeast(1L)
            var firstFrameSent = false
            var showingBlack = false

            while (running.get()) {
                val started = System.currentTimeMillis()
                val frame = FrameBus.latest()

                if (frame == null) {
                    // Nothing published (feed switched off, or still preparing).
                    // Paint black once so consumers do not freeze on a stale picture.
                    if (!showingBlack) {
                        GLES20.glClearColor(0f, 0f, 0f, 1f)
                        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                        core.setPresentationTime(eglSurface, System.nanoTime())
                        core.swapBuffers(eglSurface)
                        showingBlack = true
                    }
                    Thread.sleep(frameIntervalMs)
                    continue
                }
                showingBlack = false

                GLES20.glClearColor(0f, 0f, 0f, 1f)
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                quad.setBitmap(frame)
                // Stretch: the frame is already composed to the right layout.
                quad.drawStretched(TextureQuad.IDENTITY)
                core.setPresentationTime(eglSurface, System.nanoTime())
                core.swapBuffers(eglSurface)

                if (!firstFrameSent) {
                    firstFrameSent = true
                    listener?.onFirstFrameWritten()
                }

                val sleep = frameIntervalMs - (System.currentTimeMillis() - started)
                if (sleep > 0) Thread.sleep(sleep)
            }
        } catch (e: Exception) {
            Log.e("SurfaceFrameWriter", "$label crashed", e)
        } finally {
            running.set(false)
            quad?.release()
            core?.releaseSurface(eglSurface)
            core?.release()
            listener?.onWriterStopped()
            Log.d("SurfaceFrameWriter", "$label stopped")
        }
    }
}
