package com.teamily.virtualcamera.camera

import android.util.Log
import android.view.Surface
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Mirrors `android.hardware.camera2.CameraCaptureSession`.
 *
 * The job is narrow and identical to the real thing: bind an output [Surface] and
 * start receiving frames on it. We satisfy it with a [SurfaceFrameWriter] that
 * renders [FrameBus] into the surface, so a consumer sees a normal, continuously
 * updated camera stream.
 *
 * Unlike the real session, there is exactly one output surface. That is a
 * deliberate simplification: this virtual camera produces a single preview stream,
 * which is what every consumer in scope (viewfinder, encoder, projection display)
 * actually needs. Multi-surface / reprocessing sessions are not supported.
 */
class VirtualCaptureSession(
    private val device: VirtualCameraDevice,
    private val request: VirtualCameraDevice.CaptureRequest
) {

    companion object {
        private const val TAG = "VirtualCaptureSession"
    }

    private val closed = AtomicBoolean(false)
    private var writer: SurfaceFrameWriter? = null

    val outputSurface: Surface get() = request.outputSurface

    /** True once the writer has successfully pushed its first frame. */
    @Volatile
    var isStreaming: Boolean = false
        private set

    internal fun configure() {
        check(!closed.get()) { "Session already closed" }
        Log.d(TAG, "Configuring session for camera ${device.cameraId}")

        // The surface size is not queryable for every surface type (encoder inputs,
        // projection surfaces), so we standardise on 1280x720 — a resolution every
        // consumer in scope accepts and the decode path already produces.
        val w = SurfaceSize.of(outputSurface).first
        val h = SurfaceSize.of(outputSurface).second

        val frameWriter = SurfaceFrameWriter(
            target = request.outputSurface,
            width = w,
            height = h,
            fps = request.targetFps,
            label = "Session-${device.cameraId}"
        )
        frameWriter.listener = object : SurfaceFrameWriter.Listener {
            override fun onFirstFrameWritten() {
                isStreaming = true
                Log.d(TAG, "First frame written to consumer surface")
            }

            override fun onWriterStopped() {
                isStreaming = false
            }
        }
        writer = frameWriter
        device.attachWriter(frameWriter)
        frameWriter.start()
    }

    /** Mirrors `CameraCaptureSession.stopRepeating()`. */
    fun stopRepeating() {
        writer?.stop()
        isStreaming = false
    }

    /** Mirrors `CameraCaptureSession.close()`. */
    fun close() {
        releaseInternal()
        writer?.let { device.detachWriter(it) }
        Log.d(TAG, "Session closed")
    }

    internal fun releaseInternal() {
        if (!closed.getAndSet(true)) {
            writer?.stop()
            isStreaming = false
        }
        writer = null
    }
}

/**
 * Best-effort surface size. A [Surface] does not expose its dimensions before a
 * buffer is queued, so we fall back to the standard 720p the decode path produces.
 */
internal object SurfaceSize {
    fun of(surface: Surface): Pair<Int, Int> = 1280 to 720
}
