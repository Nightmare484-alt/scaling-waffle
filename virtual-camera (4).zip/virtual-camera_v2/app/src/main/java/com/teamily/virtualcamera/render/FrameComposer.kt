package com.teamily.virtualcamera.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import com.teamily.virtualcamera.data.FrameStyle
import com.teamily.virtualcamera.data.ScaleMode

/**
 * Bakes [FrameStyle] into the frames the app emits.
 *
 * Why here and not in each consumer: the resize/position controls have to apply to
 * *everything* at once — the in-app preview, the Camera2 surface handed to a
 * consumer, the MediaProjection display, the JPEG the camera-intent activity
 * returns, and the fullscreen screencast feed. Composing once, at the producer,
 * means those can never disagree.
 *
 * Cost: the default style ([ScaleMode.FILL], no zoom, no offset) takes the
 * zero-copy path and returns the decoder's frame untouched, so normal use pays
 * nothing. A custom layout costs one `Canvas` blit per frame — fine at 720p.
 */
object FrameComposer {

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)

    /**
     * Returns a frame of exactly [outW] x [outH] with [src] placed per [style].
     *
     * The caller owns the result. When [src] is already the right size and the
     * style is plain, [src] itself is returned and must NOT be recycled separately.
     */
    fun compose(
        src: Bitmap,
        style: FrameStyle,
        outW: Int,
        outH: Int
    ): Bitmap {
        if (src.isRecycled) return src
        if (style.isPlain && src.width == outW && src.height == outH) return src

        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        composeInto(Canvas(out), src, style, outW, outH)
        return out
    }

    /** Draws [src] into an existing [canvas] of [outW] x [outH] using [style]. */
    fun composeInto(
        canvas: Canvas,
        src: Bitmap,
        style: FrameStyle,
        outW: Int,
        outH: Int
    ) {
        canvas.drawColor(if (style.mode == ScaleMode.FILL) Color.BLACK else style.background)

        val dst = style.destinationRect(src.width, src.height, outW, outH)
        val rect = Rect(
            Math.round(dst.left),
            Math.round(dst.top),
            Math.round(dst.right),
            Math.round(dst.bottom)
        )
        canvas.drawBitmap(src, null, rect, paint)
    }

    /**
     * Draws [src] onto a caller-owned canvas that is *not* the output frame — used
     * by the drag-handle editor, where the style rect must be visible against a
     * checkerboard rather than a black frame.
     */
    fun composePreview(
        canvas: Canvas,
        src: Bitmap,
        style: FrameStyle,
        viewW: Float,
        viewH: Float
    ) {
        val dst = style.destinationRect(src.width, src.height, viewW.toInt(), viewH.toInt())
        val rect = Rect(
            Math.round(dst.left),
            Math.round(dst.top),
            Math.round(dst.right),
            Math.round(dst.bottom)
        )
        canvas.drawBitmap(src, null, rect, paint)
    }
}
