package com.teamily.virtualcamera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.teamily.virtualcamera.data.AppStateStore
import com.teamily.virtualcamera.data.MediaKind
import com.teamily.virtualcamera.data.MediaRepository
import com.teamily.virtualcamera.data.StateHub
import com.teamily.virtualcamera.databinding.ActivityMainBinding
import com.teamily.virtualcamera.service.VirtualCameraService
import com.teamily.virtualcamera.util.MediaFiles

/**
 * Home screen: pick media, start/stop the virtual camera, toggle the floating bubble,
 * and read the honest status of what is and is not possible on this device.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        /** Set by the bubble's "pick media" buttons so the picker opens on launch. */
        const val EXTRA_OPEN_PICKER = "open_picker"
    }

    private lateinit var binding: ActivityMainBinding
    private var boundService: VirtualCameraService? = null
    private var statusListener: ((String) -> Unit)? = null

    private val stateListener = StateHub.Listener { event ->
        when (event) {
            StateHub.Event.MEDIA, StateHub.Event.META, StateHub.Event.ENABLED -> {
                runOnUiThread {
                    refreshSelectedMedia()
                    refreshBubbleButton()
                }
            }
            StateHub.Event.STYLE -> Unit
        }
    }

    private val serviceConnection = object : android.content.ServiceConnection {
        override fun onServiceConnected(
            name: android.content.ComponentName?,
            binder: android.os.IBinder?
        ) {
            val local = (binder as? VirtualCameraService.LocalBinder)?.service() ?: return
            boundService = local
            val listener: (String) -> Unit = { status ->
                runOnUiThread { binding.statusText.text = status }
            }
            statusListener = listener
            local.addStatusListener(listener)
            runOnUiThread {
                binding.statusText.text = local.statusText
                refreshBubbleButton()
            }
        }

        override fun onServiceDisconnected(name: android.content.ComponentName?) {
            statusListener?.let { boundService?.removeStatusListener(it) }
            boundService = null
            statusListener = null
        }
    }

    // ---------------------------------------------------------------- pickers

    /** Photo Picker (Android 13+) or the backward-compatible SAF fallback. */
    private val pickVisualMedia = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) onMediaPicked(uri, MediaKind.VIDEO)
    }

    /** Explicit SAF picker — always available, gives persistable grants. */
    private val pickFromStorage = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val kind = if (isVideoUri(uri)) MediaKind.VIDEO else MediaKind.IMAGE
            onMediaPicked(uri, kind)
        }
    }

    private val requestNotifications = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* The service works either way; without it the notification is silent. */ }

    private val requestProjection = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, VirtualCameraService::class.java).apply {
                action = VirtualCameraService.ACTION_START_PROJECTION
                putExtra(VirtualCameraService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(VirtualCameraService.EXTRA_RESULT_DATA, data)
                putExtra(VirtualCameraService.EXTRA_FPS, 30)
            }
            ContextCompat.startForegroundService(this, intent)
            Toast.makeText(this, R.string.toast_projection_started, Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, R.string.toast_projection_denied, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUi()
        maybeAskNotificationPermission()
        refreshSelectedMedia()
        refreshBubbleButton()
        checkCameraCapability()

        // Opened from the bubble's "pick media" button?
        handlePickerExtra(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handlePickerExtra(intent)
    }

    private fun handlePickerExtra(intent: Intent?) {
        val kindName = intent?.getStringExtra(EXTRA_OPEN_PICKER) ?: return
        intent.removeExtra(EXTRA_OPEN_PICKER)
        val kind = runCatching { MediaKind.valueOf(kindName) }.getOrDefault(MediaKind.VIDEO)
        // Post so the activity is fully resumed before the picker launches.
        binding.root.post { launchPicker(kind) }
    }

    override fun onStart() {
        super.onStart()
        StateHub.addListener(stateListener)
        Intent(this, VirtualCameraService::class.java).also {
            bindService(it, serviceConnection, BIND_AUTO_CREATE)
        }
    }

    override fun onStop() {
        super.onStop()
        StateHub.removeListener(stateListener)
        statusListener?.let { boundService?.removeStatusListener(it) }
        statusListener = null
        boundService = null
        runCatching { unbindService(serviceConnection) }
    }

    // ---------------------------------------------------------------- setup

    private fun setupUi() {
        binding.pickVideo.setOnClickListener { launchPicker(MediaKind.VIDEO) }
        binding.pickImage.setOnClickListener { launchPicker(MediaKind.IMAGE) }

        binding.startVirtualCamera.setOnClickListener {
            if (AppStateStore.load(this).active == null) {
                Toast.makeText(this, R.string.toast_pick_media_first, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AppStateStore.setEnabled(this, true)
            VirtualCameraService.start(this, VirtualCameraService.ACTION_START)
            Toast.makeText(this, R.string.toast_camera_started, Toast.LENGTH_SHORT).show()
        }

        binding.stopVirtualCamera.setOnClickListener {
            AppStateStore.setEnabled(this, false)
            VirtualCameraService.start(this, VirtualCameraService.ACTION_STOP)
            Toast.makeText(this, R.string.toast_camera_stopped, Toast.LENGTH_SHORT).show()
        }

        binding.openPreview.setOnClickListener {
            if (AppStateStore.load(this).active == null) {
                Toast.makeText(this, R.string.toast_pick_media_first, Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, PreviewActivity::class.java))
            }
        }

        binding.startProjection.setOnClickListener { requestScreenCapture() }
        binding.stopProjection.setOnClickListener {
            VirtualCameraService.start(this, VirtualCameraService.ACTION_STOP_PROJECTION)
        }

        // ---- floating bubble
        binding.toggleBubble.setOnClickListener { toggleBubble() }

        // ---- YouTube guide
        binding.openGuide.setOnClickListener {
            startActivity(Intent(this, GuideActivity::class.java))
        }

        binding.howItWorks.setOnClickListener {
            startActivity(Intent(this, GuideActivity::class.java))
        }
    }

    // ---------------------------------------------------------------- bubble

    /**
     * Turns the floating bubble on or off.
     *
     * The overlay permission cannot be requested with a runtime dialog — it is a
     * Settings toggle — so when it is missing we deep-link the user straight to the
     * per-app "Display over other apps" screen and come back on resume.
     */
    private fun toggleBubble() {
        val state = AppStateStore.load(this)
        if (state.overlayBubble) {
            AppStateStore.setBubbleVisible(this, false)
            VirtualCameraService.start(this, VirtualCameraService.ACTION_HIDE_BUBBLE)
            refreshBubbleButton()
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.overlay_permission_needed, Toast.LENGTH_LONG).show()
            runCatching {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            return
        }

        AppStateStore.setBubbleVisible(this, true)
        VirtualCameraService.start(this, VirtualCameraService.ACTION_SHOW_BUBBLE)
        Toast.makeText(this, R.string.toast_overlay_granted, Toast.LENGTH_SHORT).show()
        refreshBubbleButton()
    }

    override fun onResume() {
        super.onResume()
        // Coming back from the overlay-permission screen: if the user granted it and
        // they had asked for the bubble, turn it on now.
        if (Settings.canDrawOverlays(this) && !AppStateStore.load(this).overlayBubble) {
            // Nothing to do — the user has not asked for the bubble yet.
        }
        refreshBubbleButton()
    }

    private fun refreshBubbleButton() {
        val on = AppStateStore.load(this).overlayBubble
        binding.toggleBubble.text = getString(
            if (on) R.string.hide_bubble else R.string.show_bubble
        )
        binding.toggleBubble.isSelected = on
    }

    private fun launchPicker(kind: MediaKind) {
        val requestedType = if (kind == MediaKind.VIDEO) "video/*" else "image/*"

        // Prefer the system Photo Picker on Android 13+ (no permission needed),
        // fall back to SAF OpenDocument which always returns a persistable grant.
        val usePhotoPicker = Build.VERSION.SDK_INT >= 33
        if (usePhotoPicker) {
            pickVisualMedia.launch(
                PickVisualMediaRequest(
                    if (kind == MediaKind.VIDEO) {
                        ActivityResultContracts.PickVisualMedia.VideoOnly
                    } else {
                        ActivityResultContracts.PickVisualMedia.ImageOnly
                    }
                )
            )
        } else {
            pickFromStorage.launch(arrayOf(requestedType))
        }
    }

    private fun onMediaPicked(uri: Uri, kindHint: MediaKind) {
        val kind = if (isVideoUri(uri)) MediaKind.VIDEO else kindHint
        val name = MediaRepository.displayName(this, uri)
        AppStateStore.pick(this, uri, kind, name)
        refreshSelectedMedia()

        // Restart the engine immediately if the service is already up.
        if (VirtualCameraService.isRunning) {
            VirtualCameraService.start(this, VirtualCameraService.ACTION_RELOAD_MEDIA)
        }
        Toast.makeText(this, getString(R.string.toast_selected, name), Toast.LENGTH_SHORT).show()
    }

    private fun refreshSelectedMedia() {
        val state = AppStateStore.load(this)
        val selection = state.active
        if (selection == null) {
            binding.selectedName.text = getString(R.string.no_media_selected)
            binding.selectedKind.text = ""
            binding.previewThumb.setImageDrawable(null)
            binding.openPreview.isEnabled = false
            return
        }

        binding.selectedName.text = selection.displayName
        binding.selectedKind.text = getString(
            if (selection.isVideo) R.string.kind_video else R.string.kind_image
        )
        binding.openPreview.isEnabled = true

        // Thumbnail: video frame or decoded image, on a background thread.
        Thread {
            val bitmap = if (selection.isVideo) {
                MediaFiles.videoFrame(this, selection.uri)
            } else {
                MediaFiles.decodeBitmap(this, selection.uri, 640)
            }
            if (bitmap != null) {
                runOnUiThread { binding.previewThumb.setImageBitmap(bitmap) }
            }
        }.start()
    }

    /** Reports what this build can and cannot do on the current device. */
    private fun checkCameraCapability() {
        val hasCameraFeature = packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
        val isDefaultCamera = isProbablyDefaultCameraApp()
        val canOverlay = Settings.canDrawOverlays(this)

        binding.capabilityText.text = buildString {
            append(getString(R.string.capability_device, Build.MANUFACTURER, Build.MODEL))
            append("\n")
            append(getString(R.string.capability_hardware, if (hasCameraFeature) "yes" else "no"))
            append("\n")
            append(
                getString(
                    R.string.capability_default_camera,
                    if (isDefaultCamera) getString(R.string.yes) else getString(R.string.not_yet)
                )
            )
            append("\n")
            append("Overlay permission: ${if (canOverlay) "granted" else "not granted"}")
            append("\n")
            append(getString(R.string.capability_projection_ready))
        }
    }

    private fun isProbablyDefaultCameraApp(): Boolean {
        val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
        val resolved = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolved?.activityInfo?.packageName == packageName
    }

    private fun maybeAskNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // ---------------------------------------------------------------- projection

    private fun requestScreenCapture() {
        if (AppStateStore.load(this).active == null) {
            Toast.makeText(this, R.string.toast_pick_media_first, Toast.LENGTH_SHORT).show()
            return
        }
        val manager = getSystemService(android.media.projection.MediaProjectionManager::class.java)
        requestProjection.launch(manager.createScreenCaptureIntent())
    }

    private fun isVideoUri(uri: Uri): Boolean {
        val mime = contentResolver.getType(uri).orEmpty()
        if (mime.startsWith("video/")) return true
        if (mime.startsWith("image/")) return false
        val name = MediaRepository.displayName(this, uri).lowercase()
        return name.endsWith(".mp4") || name.endsWith(".mkv") || name.endsWith(".webm") ||
            name.endsWith(".mov") || name.endsWith(".3gp") || name.endsWith(".m4v")
    }
}
