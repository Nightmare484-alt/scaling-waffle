package com.teamily.virtualcamera.data

import android.content.Context
import android.graphics.RectF
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * How the source media is placed inside the 1280x720 output frame.
 *
 * The overlay's size chips, its zoom slider, the position pad and the drag handles
 * in [com.teamily.virtualcamera.FrameEditorActivity] all write to this one object,
 * and every consumer (preview, Camera2 surface, MediaProjection writer, the
 * fullscreen screen-feed window) renders through it — so what you arrange on screen
 * is exactly what other apps receive.
 */
enum class ScaleMode {
    /** Whole media visible, letterboxed. */
    FIT,

    /** Media covers the frame, edges cropped (default — looks like a real camera). */
    FILL,

    /** Media stretched to the frame, aspect distorted. */
    STRETCH,

    /** Free resize: independent width/height, set by the drag handles. */
    FREE
}

data class FrameStyle(
    val mode: ScaleMode = ScaleMode.FILL,
    /** Extra zoom on top of the mode's base size. 1.0 = no extra zoom. */
    val zoom: Float = 1f,
    /** FREE mode: width as a fraction of the output frame. */
    val scaleX: Float = 1f,
    /** FREE mode: height as a fraction of the output frame. */
    val scaleY: Float = 1f,
    /** Horizontal offset, -1..1 where 1 moves the media half a frame to the right. */
    val offsetX: Float = 0f,
    /** Vertical offset, -1..1 where 1 moves the media half a frame down. */
    val offsetY: Float = 0f,
    /** Filled behind the media, visible in FIT / FREE modes. */
    val background: Int = 0xFF000000.toInt()
) {

    /** True when nothing is customised — lets the renderer take the cheap path. */
    val isPlain: Boolean
        get() = mode == ScaleMode.FILL && zoom == 1f && offsetX == 0f && offsetY == 0f

    /**
     * Where the source image is drawn inside an [outW] x [outH] frame.
     *
     * Everything is derived here (and only here) so the GL preview, the CPU
     * composer and the drag-handle editor can never disagree about the geometry.
     */
    fun destinationRect(srcW: Int, srcH: Int, outW: Int, outH: Int): RectF {
        if (srcW <= 0 || srcH <= 0 || outW <= 0 || outH <= 0) {
            return RectF(0f, 0f, outW.toFloat(), outH.toFloat())
        }
        val sw = srcW.toFloat()
        val sh = srcH.toFloat()
        val ow = outW.toFloat()
        val oh = outH.toFloat()

        var w: Float
        var h: Float
        when (mode) {
            ScaleMode.STRETCH -> {
                w = ow
                h = oh
            }
            ScaleMode.FREE -> {
                w = ow * scaleX.coerceIn(0.05f, 4f)
                h = oh * scaleY.coerceIn(0.05f, 4f)
            }
            ScaleMode.FIT -> {
                val s = min(ow / sw, oh / sh)
                w = sw * s
                h = sh * s
            }
            ScaleMode.FILL -> {
                val s = max(ow / sw, oh / sh)
                w = sw * s
                h = sh * s
            }
        }

        // Zoom multiplies the final size in every mode, including free resize.
        val z = zoom.coerceIn(0.2f, 4f)
        w *= z
        h *= z

        val cx = ow / 2f + offsetX.coerceIn(-2f, 2f) * ow / 2f
        val cy = oh / 2f + offsetY.coerceIn(-2f, 2f) * oh / 2f

        return RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
    }

    /** Derives a FREE-mode style from a dragged rectangle. Used by the handle editor. */
    fun withRect(rect: RectF, outW: Int, outH: Int): FrameStyle {
        val w = rect.width().coerceAtLeast(24f) / outW.toFloat()
        val h = rect.height().coerceAtLeast(24f) / outH.toFloat()
        val cx = rect.centerX() / outW.toFloat()
        val cy = rect.centerY() / outH.toFloat()
        return copy(
            mode = ScaleMode.FREE,
            zoom = 1f,
            scaleX = w.coerceIn(0.05f, 4f),
            scaleY = h.coerceIn(0.05f, 4f),
            offsetX = ((cx - 0.5f) * 2f).coerceIn(-2f, 2f),
            offsetY = ((cy - 0.5f) * 2f).coerceIn(-2f, 2f)
        )
    }
}

/** Persists the frame arrangement so the bubble, editor and service all agree. */
object FrameStyleStore {

    private const val PREFS = "vc_frame_style"
    private const val K_MODE = "mode"
    private const val K_ZOOM = "zoom"
    private const val K_SX = "scale_x"
    private const val K_SY = "scale_y"
    private const val K_OX = "offset_x"
    private const val K_OY = "offset_y"

    fun load(context: Context): FrameStyle {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val mode = runCatching {
            ScaleMode.valueOf(p.getString(K_MODE, ScaleMode.FILL.name)!!)
        }.getOrDefault(ScaleMode.FILL)
        return FrameStyle(
            mode = mode,
            zoom = p.getFloat(K_ZOOM, 1f),
            scaleX = p.getFloat(K_SX, 1f),
            scaleY = p.getFloat(K_SY, 1f),
            offsetX = p.getFloat(K_OX, 0f),
            offsetY = p.getFloat(K_OY, 0f)
        )
    }

    fun save(context: Context, style: FrameStyle) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(K_MODE, style.mode.name)
            .putFloat(K_ZOOM, style.zoom)
            .putFloat(K_SX, style.scaleX)
            .putFloat(K_SY, style.scaleY)
            .putFloat(K_OX, style.offsetX)
            .putFloat(K_OY, style.offsetY)
            .apply()
        StateHub.post(StateHub.Event.STYLE)
    }

    fun reset(context: Context) {
        save(context, FrameStyle())
    }
}

/** Small integer helpers used by the sliders and the pad. */
object StyleMath {
    fun percent(zoom: Float): Int = (zoom * 100f).roundToInt()
    fun fromPercent(percent: Int): Float = (percent / 100f).coerceIn(0.2f, 4f)
}
