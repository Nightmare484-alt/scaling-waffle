package com.teamily.virtualcamera.projection

import android.content.Context
import android.content.Intent
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import com.teamily.virtualcamera.camera.FrameBus
import com.teamily.virtualcamera.camera.SurfaceFrameWriter

/**
 * FALLBACK MODE — screen-capture source.
 *
 * Why this exists: many desktop / streaming apps accept a *screen share* as a video
 * source even when they will not let you pick a third-party camera. So instead of (or
 * in addition to) the camera-intent path, the user can start a MediaProjection and pick
 * **"Virtual Camera — Screen"** in Zoom / Meet / OBS / Discord, etc.
 *
 * How it works: [MediaProjection] gives us a virtual display whose output surface we
 * own, and we render the selected media into it via [SurfaceFrameWriter]. To the
 * receiving app it looks like a mirrored display that happens to show a video.
 *
 * ## Honest limits
 *  - The OS shows a persistent "screen is being captured / shared" indicator and, on
 *    Android 14+, requires a per-session user consent dialog. There is no way around
 *    that — it is a deliberate platform anti-abuse control.
 *  - On Android 14+ `MediaProjection` refuses to start from anything but a foreground
 *    service of type `mediaProjection` that was started *after* consent.
 *    [com.teamily.virtualcamera.service.VirtualCameraService] handles that order.
 *  - What the receiving app sees is a screen share, not a camera. Apps that strictly
 *    require a camera device will not accept it.
 *  - **This is not the YouTube path.** YouTube's mobile app does not consume a
 *    MediaProjection from another app; its own "Screencast" mode captures the screen
 *    itself. For YouTube, use [com.teamily.virtualcamera.ScreenFeedActivity].
 */
class ScreenCaptureSource(private val context: Context) {

    companion object {
        private const val TAG = "ScreenCaptureSource"
        private const val DISPLAY_NAME = "VirtualCamera"
        const val VIRTUAL_DISPLAY_WIDTH = 1280
        const val VIRTUAL_DISPLAY_HEIGHT = 720
        const val VIRTUAL_DISPLAY_DPI = 320
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var writer: SurfaceFrameWriter? = null
    private var surface: Surface? = null
    private var surfaceTexture: SurfaceTexture? = null

    var onStatus: ((String) -> Unit)? = null

    /** True once a projection is running and media is being pushed into it. */
    val isActive: Boolean get() = virtualDisplay != null

    /**
     * Starts projection using the result data from the consent dialog.
     *
     * Must be called from a context that is allowed to register the callback — a
     * foreground service is the reliable choice on Android 14+.
     */
    fun start(resultCode: Int, data: Intent, fps: Int = 30): Boolean {
        stop()

        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                as MediaProjectionManager

        return try {
            val mp = manager.getMediaProjection(resultCode, data)
            if (mp == null) {
                onStatus?.invoke("Screen capture permission was not granted")
                return false
            }
            projection = mp

            // Android 14+ requires the callback to be registered before the virtual
            // display is created, otherwise it throws SecurityException.
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.d(TAG, "MediaProjection stopped by the system")
                    stop()
                    onStatus?.invoke("Screen capture stopped")
                }
            }, Handler(Looper.getMainLooper()))

            // One display, created directly against a Surface we own. (An earlier
            // version created a throwaway display with a null surface and released it
            // again — that was pointless and could leave the projection in a bad
            // state on some OEM builds.)
            val tex = SurfaceTexture(0).apply {
                setDefaultBufferSize(VIRTUAL_DISPLAY_WIDTH, VIRTUAL_DISPLAY_HEIGHT)
            }
            surfaceTexture = tex
            val s = Surface(tex)
            surface = s

            val display = mp.createVirtualDisplay(
                DISPLAY_NAME,
                VIRTUAL_DISPLAY_WIDTH,
                VIRTUAL_DISPLAY_HEIGHT,
                VIRTUAL_DISPLAY_DPI,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                s,
                null,
                null
            )
            if (display == null) {
                onStatus?.invoke("Could not create the virtual display")
                stop()
                return false
            }
            virtualDisplay = display

            // Feed the display from the same FrameBus the camera path uses.
            val w = SurfaceFrameWriter(
                target = s,
                width = VIRTUAL_DISPLAY_WIDTH,
                height = VIRTUAL_DISPLAY_HEIGHT,
                fps = fps,
                label = "ProjectionWriter"
            )
            writer = w
            w.start()

            onStatus?.invoke("Screen capture running — pick \"Screen\" in the other app")
            true
        } catch (e: Exception) {
            Log.e(TAG, "start failed", e)
            onStatus?.invoke("Screen capture failed: ${e.message}")
            stop()
            false
        }
    }

    /** True when there is a live frame to mirror. */
    fun attachToBus(): Boolean = FrameBus.isLive

    fun stop() {
        writer?.stop()
        writer = null
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { surface?.release() }
        surface = null
        runCatching { surfaceTexture?.release() }
        surfaceTexture = null
        runCatching { projection?.stop() }
        projection = null
    }
}
