package com.teamily.virtualcamera

import android.graphics.Bitmap
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.teamily.virtualcamera.camera.FrameBus
import com.teamily.virtualcamera.data.AppStateStore
import com.teamily.virtualcamera.data.FrameStyle
import com.teamily.virtualcamera.data.FrameStyleStore
import com.teamily.virtualcamera.data.ScaleMode
import com.teamily.virtualcamera.databinding.ActivityFrameEditorBinding
import com.teamily.virtualcamera.util.MediaFiles

/**
 * Full-screen drag-handle editor for the media's size and position.
 *
 * The bubble's panel has a compact position pad and a zoom slider for quick tweaks;
 * this screen is for precise work — drag a corner to free-resize, drag the picture to
 * move it, pinch to zoom, with rule-of-thirds guides.
 *
 * It edits the *same* [FrameStyle] the output uses, so what is arranged here is what
 * other apps receive. Changes are saved on every gesture (not on exit) so a crash or a
 * swipe-away cannot lose the layout.
 */
class FrameEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFrameEditorBinding
    private var style: FrameStyle = FrameStyle()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFrameEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        style = FrameStyleStore.load(this)
        binding.editorView.setStyle(style)
        binding.editorView.onStyleChanged = { next ->
            style = next
            FrameStyleStore.save(this, next)
            syncChips()
        }

        loadPreviewBitmap()
        syncChips()

        binding.editorDone.setOnClickListener { finish() }

        binding.editorModeFit.setOnClickListener { setMode(ScaleMode.FIT) }
        binding.editorModeFill.setOnClickListener { setMode(ScaleMode.FILL) }
        binding.editorModeStretch.setOnClickListener { setMode(ScaleMode.STRETCH) }

        binding.editorReset.setOnClickListener {
            style = FrameStyle()
            FrameStyleStore.save(this, style)
            binding.editorView.setStyle(style)
            syncChips()
        }
    }

    /**
     * Uses the live frame when the service is running (so the editor shows the real
     * decoded picture), otherwise decodes the selected file directly.
     */
    private fun loadPreviewBitmap() {
        val live = FrameBus.latest()
        if (live != null) {
            binding.editorView.setBitmap(live)
            return
        }

        val state = AppStateStore.load(this)
        val selection = state.active ?: return
        Thread {
            val bitmap: Bitmap? = if (selection.isVideo) {
                MediaFiles.videoFrame(this, selection.uri)
            } else {
                MediaFiles.decodeBitmap(this, selection.uri, 1280)
            }
            if (bitmap != null) {
                runOnUiThread { binding.editorView.setBitmap(bitmap) }
            }
        }.start()
    }

    private fun setMode(mode: ScaleMode) {
        style = style.copy(mode = mode)
        FrameStyleStore.save(this, style)
        binding.editorView.setStyle(style)
        syncChips()
    }

    private fun syncChips() {
        markSelected(binding.editorModeFit, style.mode == ScaleMode.FIT)
        markSelected(binding.editorModeFill, style.mode == ScaleMode.FILL)
        markSelected(binding.editorModeStretch, style.mode == ScaleMode.STRETCH)
    }

    private fun markSelected(view: TextView, selected: Boolean) {
        view.isSelected = selected
    }
}
