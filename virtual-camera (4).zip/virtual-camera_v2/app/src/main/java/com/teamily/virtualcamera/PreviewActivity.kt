package com.teamily.virtualcamera

import android.os.Bundle
import android.view.SurfaceHolder
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.teamily.virtualcamera.camera.FrameBus
import com.teamily.virtualcamera.camera.SurfaceFrameWriter
import com.teamily.virtualcamera.data.AppStateStore
import com.teamily.virtualcamera.databinding.ActivityPreviewBinding
import com.teamily.virtualcamera.media.MediaEngine
import com.teamily.virtualcamera.service.VirtualCameraService
import android.content.Intent

/**
 * Live preview of exactly what the virtual camera is emitting.
 *
 * Deliberately *not* an ExoPlayer view: it renders the same [FrameBus] frames the
 * camera path emits, through the same [SurfaceFrameWriter]. If it looks right here,
 * that is what consumers receive — preview and output can never drift apart.
 */
class PreviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPreviewBinding
    private var engine: MediaEngine? = null
    private var writer: SurfaceFrameWriter? = null
    private var ownsEngine = false
    private var frameCount = 0L
    private var lastFpsAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val selection = AppStateStore.load(this).active
        if (selection == null) {
            finish()
            return
        }

        binding.previewName.text = selection.displayName

        // If the foreground service already owns playback, just observe it.
        // Otherwise run a local engine so the preview works standalone.
        if (!VirtualCameraService.isRunning) {
            engine = MediaEngine(applicationContext).also { eng ->
                ownsEngine = true
                eng.onStateChanged = { state, msg ->
                    runOnUiThread {
                        binding.previewStatus.text = msg ?: state.name
                        binding.progress.visibility =
                            if (state == MediaEngine.State.PREPARING) View.VISIBLE else View.GONE
                    }
                }
                eng.onFrame = { onFrameCounted() }
                eng.start(selection)
            }
        } else {
            binding.previewStatus.text = getString(R.string.preview_from_service)
            FrameBus.addListener { onFrameCounted() }
        }

        binding.previewSurface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                startWriter(holder)
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                writer?.stop()
                startWriter(holder)
            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                writer?.stop()
                writer = null
            }
        })

        binding.closePreview.setOnClickListener { finish() }
    }

    private fun startWriter(holder: SurfaceHolder) {
        val w = SurfaceFrameWriter(
            target = holder.surface,
            width = (holder.surfaceFrame?.width() ?: 1280).coerceAtLeast(2),
            height = (holder.surfaceFrame?.height() ?: 720).coerceAtLeast(2),
            fps = 30,
            label = "PreviewWriter"
        )
        w.listener = object : SurfaceFrameWriter.Listener {
            override fun onFirstFrameWritten() {
                runOnUiThread { binding.progress.visibility = View.GONE }
            }

            override fun onWriterStopped() = Unit
        }
        writer = w
        w.start()
    }

    private fun onFrameCounted() {
        frameCount++
        val now = System.currentTimeMillis()
        if (lastFpsAt == 0L) lastFpsAt = now
        if (now - lastFpsAt >= 1000) {
            val fps = frameCount * 1000 / (now - lastFpsAt)
            frameCount = 0
            lastFpsAt = now
            runOnUiThread { binding.previewFps.text = getString(R.string.preview_fps, fps) }
        }
    }

    override fun onDestroy() {
        writer?.stop()
        writer = null
        if (ownsEngine) {
            engine?.release()
            engine = null
        }
        super.onDestroy()
    }
}
