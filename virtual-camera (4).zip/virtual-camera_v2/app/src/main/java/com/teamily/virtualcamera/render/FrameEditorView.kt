package com.teamily.virtualcamera.render

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.teamily.virtualcamera.data.FrameStyle
import com.teamily.virtualcamera.data.ScaleMode
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * The drag-handle editor: the media drawn inside a 16:9 frame with four corner
 * handles and a move gesture.
 *
 * ## Why a custom View and not a stack of ImageViews
 * The handles must stay glued to the *composed* rect, which is computed by
 * [FrameStyle.destinationRect] — the same function the real output uses. Drawing both
 * the picture and the handles from that one rect is what guarantees the editor shows
 * the truth. A separate overlay view would need its own copy of the geometry and would
 * eventually disagree with the output.
 *
 * ## Gestures
 *  - Drag inside the picture → move it (writes offsetX / offsetY).
 *  - Drag a corner handle → free resize (switches to [ScaleMode.FREE]).
 *  - Pinch → zoom (writes [FrameStyle.zoom]).
 *
 * Every change is reported through [onStyleChanged] so the caller can persist it; the
 * view never writes to storage itself.
 */
class FrameEditorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        private const val HANDLE_RADIUS_DP = 11f
        private const val TOUCH_SLOP_DP = 22f
    }

    private val density = resources.displayMetrics.density
    private val handleRadius = HANDLE_RADIUS_DP * density
    private val touchSlop = TOUCH_SLOP_DP * density

    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
        color = 0x66FFFFFF
    }
    private val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF4ADE80.toInt()
    }
    private val handleStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        color = 0xFF0B0E13.toInt()
    }
    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
        color = 0x33FFFFFF
    }

    private var bitmap: Bitmap? = null
    private var style: FrameStyle = FrameStyle()

    /** Called on every gesture-driven change. */
    var onStyleChanged: ((FrameStyle) -> Unit)? = null

    /** The 16:9 output frame, letterboxed inside this view. */
    private val frameRect = RectF()

    private enum class Drag { NONE, MOVE, TL, TR, BL, BR }

    private var drag = Drag.NONE
    private var lastX = 0f
    private var lastY = 0f

    // Pinch state
    private var pinchStartDistance = 0f
    private var pinchStartZoom = 1f

    fun setBitmap(value: Bitmap?) {
        bitmap = value
        invalidate()
    }

    fun setStyle(value: FrameStyle) {
        style = value
        invalidate()
    }

    fun currentStyle(): FrameStyle = style

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // Letterbox a 16:9 frame inside the view — the same aspect the output uses.
        val targetAspect = 16f / 9f
        val viewAspect = w.toFloat() / h.toFloat()
        if (viewAspect > targetAspect) {
            val fw = h * targetAspect
            val left = (w - fw) / 2f
            frameRect.set(left, 0f, left + fw, h.toFloat())
        } else {
            val fh = w / targetAspect
            val top = (h - fh) / 2f
            frameRect.set(0f, top, w.toFloat(), top + fh)
        }
    }

    /** The composed media rect in view coordinates. */
    private fun mediaRect(): RectF {
        val bmp = bitmap ?: return RectF(frameRect)
        val dst = style.destinationRect(
            bmp.width, bmp.height,
            frameRect.width().toInt(), frameRect.height().toInt()
        )
        return RectF(
            frameRect.left + dst.left,
            frameRect.top + dst.top,
            frameRect.left + dst.right,
            frameRect.top + dst.bottom
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Frame background + border.
        canvas.drawColor(0xFF0B0E13.toInt())
        canvas.drawRect(frameRect, Paint().apply { color = Color.BLACK })

        val bmp = bitmap
        if (bmp != null && !bmp.isRecycled) {
            canvas.drawBitmap(bmp, null, mediaRect(), bitmapPaint)
        }

        // Rule-of-thirds guides, so the user can centre a face.
        for (i in 1..2) {
            val x = frameRect.left + frameRect.width() * i / 3f
            val y = frameRect.top + frameRect.height() * i / 3f
            canvas.drawLine(x, frameRect.top, x, frameRect.bottom, guidePaint)
            canvas.drawLine(frameRect.left, y, frameRect.right, y, guidePaint)
        }

        canvas.drawRect(frameRect, framePaint)

        // Corner handles on the media rect.
        val r = mediaRect()
        listOf(
            r.left to r.top,
            r.right to r.top,
            r.left to r.bottom,
            r.right to r.bottom
        ).forEach { (x, y) ->
            canvas.drawCircle(x, y, handleRadius, handleFill)
            canvas.drawCircle(x, y, handleRadius, handleStroke)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                drag = hitTest(event.x, event.y)
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount >= 2) {
                    pinchStartDistance = distance(event)
                    pinchStartZoom = style.zoom
                    drag = Drag.NONE
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    val d = distance(event)
                    if (pinchStartDistance > 0f) {
                        val factor = d / pinchStartDistance
                        val next = style.copy(
                            zoom = (pinchStartZoom * factor).coerceIn(0.2f, 4f)
                        )
                        applyStyle(next)
                    }
                    return true
                }

                val dx = event.x - lastX
                val dy = event.y - lastY
                lastX = event.x
                lastY = event.y

                when (drag) {
                    Drag.MOVE -> {
                        val w = frameRect.width().coerceAtLeast(1f)
                        val h = frameRect.height().coerceAtLeast(1f)
                        applyStyle(
                            style.copy(
                                offsetX = (style.offsetX + dx / w * 2f).coerceIn(-2f, 2f),
                                offsetY = (style.offsetY + dy / h * 2f).coerceIn(-2f, 2f)
                            )
                        )
                    }

                    Drag.TL, Drag.TR, Drag.BL, Drag.BR -> {
                        val r = mediaRect()
                        when (drag) {
                            Drag.TL -> { r.left += dx; r.top += dy }
                            Drag.TR -> { r.right += dx; r.top += dy }
                            Drag.BL -> { r.left += dx; r.bottom += dy }
                            else -> { r.right += dx; r.bottom += dy }
                        }
                        // Keep a sane minimum so the rect cannot invert.
                        if (r.width() < 40f || r.height() < 40f) return true
                        applyStyle(
                            style.withRect(
                                r,
                                frameRect.width().toInt().coerceAtLeast(1),
                                frameRect.height().toInt().coerceAtLeast(1)
                            )
                        )
                    }

                    Drag.NONE -> Unit
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                drag = Drag.NONE
                pinchStartDistance = 0f
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun applyStyle(next: FrameStyle) {
        style = next
        invalidate()
        onStyleChanged?.invoke(next)
    }

    private fun hitTest(x: Float, y: Float): Drag {
        val r = mediaRect()
        val corners = listOf(
            Drag.TL to (r.left to r.top),
            Drag.TR to (r.right to r.top),
            Drag.BL to (r.left to r.bottom),
            Drag.BR to (r.right to r.bottom)
        )
        for ((kind, point) in corners) {
            if (abs(x - point.first) <= touchSlop && abs(y - point.second) <= touchSlop) {
                return kind
            }
        }
        return if (r.contains(x, y)) Drag.MOVE else Drag.NONE
    }

    private fun distance(event: MotionEvent): Float {
        if (event.pointerCount < 2) return 0f
        val dx = event.getX(0) - event.getX(1)
        val dy = event.getY(0) - event.getY(1)
        return max(1f, kotlin.math.hypot(dx, dy))
    }
}
