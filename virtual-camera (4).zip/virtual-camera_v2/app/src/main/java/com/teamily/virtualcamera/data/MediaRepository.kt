package com.teamily.virtualcamera.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns

/**
 * Persists the chosen media file so the foreground service (a different process
 * lifetime than the picker activity) can still open it.
 *
 * We also keep an explicit persisted read permission on the URI, which Android
 * grants through the Storage Access Framework and which survives reboots.
 */
object MediaRepository {

    private const val PREFS = "virtual_camera_prefs"
    private const val KEY_URI = "selected_uri"
    private const val KEY_KIND = "selected_kind"
    private const val KEY_NAME = "selected_name"

    fun save(context: Context, uri: Uri, kind: MediaKind, displayName: String) {
        // Persist read access so the file stays readable across app restarts.
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: SecurityException) {
            // Some providers (e.g. media store items handed out by the photo
            // picker) do not support persistable grants. The URI still works for
            // this process, we just may need to re-pick after a restart.
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_URI, uri.toString())
            .putString(KEY_KIND, kind.name)
            .putString(KEY_NAME, displayName)
            .apply()
    }

    fun load(context: Context): MediaSelection? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val uriString = prefs.getString(KEY_URI, null) ?: return null
        val kind = runCatching {
            MediaKind.valueOf(prefs.getString(KEY_KIND, MediaKind.VIDEO.name)!!)
        }.getOrDefault(MediaKind.VIDEO)
        val name = prefs.getString(KEY_NAME, null) ?: "selected media"

        val uri = Uri.parse(uriString)
        return MediaSelection(uri, kind, name)
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    /** True when we can still read [uri] (grant present, file not deleted). */
    fun canRead(context: Context, uri: Uri): Boolean {
        val persisted = context.contentResolver.persistedUriPermissions
            .any { it.uri == uri && it.isReadPermission }
        if (persisted) return true
        return runCatching {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
        }.getOrDefault(false)
    }

    /** Human readable name for a SAF URI, used by the picker screen and the service. */
    fun displayName(context: Context, uri: Uri): String {
        if (uri.scheme == "content") {
            runCatching {
                context.contentResolver.query(
                    uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (index >= 0) {
                            cursor.getString(index)?.let { return it }
                        }
                    }
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "selected media"
    }
}
