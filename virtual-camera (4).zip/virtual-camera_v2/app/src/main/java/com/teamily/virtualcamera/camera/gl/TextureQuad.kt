package com.teamily.virtualcamera.camera.gl

import android.graphics.Bitmap
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * Full-screen textured quad.
 *
 * Two flavours:
 *  - [external] = false → samples a normal `sampler2D` (bitmaps we upload).
 *  - [external] = true  → samples `samplerExternalOES`, the texture type a video
 *    decoder writes into via [android.graphics.SurfaceTexture]. This is how
 *    ExoPlayer's output reaches our EGL pipeline without a CPU copy.
 *
 * Aspect-fill is baked into the texture coordinates so the picture covers the
 * destination without letterboxing.
 */
class TextureQuad(private val external: Boolean) {

    private var program = 0
    private var aPosition = 0
    private var aTexCoord = 0
    private var uTexMatrix = 0
    private var uTexture = 0
    private var textureId = 0

    private val vertexBuffer: FloatBuffer = ByteBuffer
        .allocateDirect(VERTICES.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(VERTICES)
            position(0)
        }

    private val texBuffer: FloatBuffer = ByteBuffer
        .allocateDirect(TEX_COORDS.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(TEX_COORDS)
            position(0)
        }

    /**
     * Texture coordinates with V inverted.
     *
     * Needed for the bitmap path: `GLUtils.texImage2D` uploads row 0 of a Bitmap at
     * t=0, but our quad's t=0 corner is the *bottom* of the viewport. Without this
     * flip every frame we blit from a Bitmap comes out upside down.
     *
     * The external-OES path does not use it — `SurfaceTexture.getTransformMatrix`
     * already carries the decoder's orientation.
     */
    private val texBufferFlipped: FloatBuffer = ByteBuffer
        .allocateDirect(TEX_COORDS_FLIPPED.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(TEX_COORDS_FLIPPED)
            position(0)
        }

    init {
        val vertexShader = compile(VERTEX_SHADER, GLES20.GL_VERTEX_SHADER)
        val fragmentShader = compile(
            if (external) FRAGMENT_OES else FRAGMENT_2D,
            GLES20.GL_FRAGMENT_SHADER
        )
        program = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, vertexShader)
            GLES20.glAttachShader(it, fragmentShader)
            GLES20.glLinkProgram(it)
            val status = IntArray(1)
            GLES20.glGetProgramiv(it, GLES20.GL_LINK_STATUS, status, 0)
            check(status[0] == GLES20.GL_TRUE) { "Program link failed" }
        }

        aPosition = GLES20.glGetAttribLocation(program, "aPosition")
        aTexCoord = GLES20.glGetAttribLocation(program, "aTexCoord")
        uTexMatrix = GLES20.glGetUniformLocation(program, "uTexMatrix")
        uTexture = GLES20.glGetUniformLocation(program, "sTexture")

        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES20.glBindTexture(target, textureId)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    private val target: Int
        get() = if (external) GLES11Ext.GL_TEXTURE_EXTERNAL_OES else GLES20.GL_TEXTURE_2D

    val texture: Int get() = textureId

    /** Uploads [bitmap] into the 2D texture (ignored in OES mode). */
    fun setBitmap(bitmap: Bitmap) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
    }

    /**
     * Draws the bound texture across the current viewport with aspect-fill.
     *
     * @param texMatrix 4x4 column-major transform from `SurfaceTexture.getTransformMatrix`
     *                  (OES mode); pass identity for bitmaps.
     * @param srcAspect source width/height, used for the aspect-fill crop.
     */
    fun draw(texMatrix: FloatArray, srcAspect: Float) {
        GLES20.glUseProgram(program)

        // Aspect-fill: scale the texture coordinates so the source covers the viewport.
        val dstAspect = viewportAspect
        val sx: Float
        val sy: Float
        if (srcAspect > dstAspect) {
            sx = dstAspect / srcAspect
            sy = 1f
        } else {
            sx = 1f
            sy = srcAspect / dstAspect
        }

        val m = texMatrix.copyOf()
        // Compose the crop into the transform: texCoord' = (crop * matrix) * texCoord
        val crop = floatArrayOf(sx, 0f, 0f, 0f, 0f, sy, 0f, 0f, 0f, 0f, 1f, 0f, (1f - sx) / 2f, (1f - sy) / 2f, 0f, 1f)
        val composed = multiply(crop, m)

        GLES20.glUniformMatrix4fv(uTexMatrix, 1, false, composed, 0)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(target, textureId)
        GLES20.glUniform1i(uTexture, 0)

        GLES20.glEnableVertexAttribArray(aPosition)
        GLES20.glVertexAttribPointer(aPosition, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer)
        GLES20.glEnableVertexAttribArray(aTexCoord)
        GLES20.glVertexAttribPointer(aTexCoord, 2, GLES20.GL_FLOAT, false, 0, texBuffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(aPosition)
        GLES20.glDisableVertexAttribArray(aTexCoord)
    }

    /**
     * Draws the bound texture across the whole viewport with **no** aspect
     * correction — a straight 1:1 blit.
     *
     * Used when the frame arriving from [com.teamily.virtualcamera.camera.FrameBus]
     * has already been composed to the destination size by
     * [com.teamily.virtualcamera.render.FrameComposer]. Doing any crop here as well
     * would quietly convert a user's "Fit" layout back into a "Fill".
     */
    fun drawStretched(texMatrix: FloatArray) {
        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(uTexMatrix, 1, false, texMatrix, 0)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(target, textureId)
        GLES20.glUniform1i(uTexture, 0)

        GLES20.glEnableVertexAttribArray(aPosition)
        GLES20.glVertexAttribPointer(aPosition, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer)
        GLES20.glEnableVertexAttribArray(aTexCoord)
        GLES20.glVertexAttribPointer(aTexCoord, 2, GLES20.GL_FLOAT, false, 0, texBufferFlipped)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(aPosition)
        GLES20.glDisableVertexAttribArray(aTexCoord)
    }

    /** Set by the renderer before [draw] so aspect-fill knows the destination shape. */
    var viewportAspect: Float = 16f / 9f

    fun release() {
        if (program != 0) GLES20.glDeleteProgram(program)
        if (textureId != 0) GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
        program = 0
        textureId = 0
    }

    private fun compile(source: String, type: Int): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        check(status[0] == GLES20.GL_TRUE) {
            "Shader compile failed: " + GLES20.glGetShaderInfoLog(shader)
        }
        return shader
    }

    private fun multiply(a: FloatArray, b: FloatArray): FloatArray {
        val out = FloatArray(16)
        for (col in 0 until 4) {
            for (row in 0 until 4) {
                var sum = 0f
                for (k in 0 until 4) {
                    sum += a[k * 4 + row] * b[col * 4 + k]
                }
                out[col * 4 + row] = sum
            }
        }
        return out
    }

    companion object {
        private val VERTICES = floatArrayOf(
            -1f, -1f,
            1f, -1f,
            -1f, 1f,
            1f, 1f
        )
        private val TEX_COORDS = floatArrayOf(
            0f, 0f,
            1f, 0f,
            0f, 1f,
            1f, 1f
        )

        /** Same corners, V inverted — see [texBufferFlipped]. */
        private val TEX_COORDS_FLIPPED = floatArrayOf(
            0f, 1f,
            1f, 1f,
            0f, 0f,
            1f, 0f
        )

        private const val VERTEX_SHADER = """
            uniform mat4 uTexMatrix;
            attribute vec4 aPosition;
            attribute vec4 aTexCoord;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = aPosition;
                vTexCoord = (uTexMatrix * aTexCoord).xy;
            }
        """

        private const val FRAGMENT_2D = """
            precision mediump float;
            uniform sampler2D sTexture;
            varying vec2 vTexCoord;
            void main() {
                gl_FragColor = texture2D(sTexture, vTexCoord);
            }
        """

        private const val FRAGMENT_OES = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            uniform samplerExternalOES sTexture;
            varying vec2 vTexCoord;
            void main() {
                gl_FragColor = texture2D(sTexture, vTexCoord);
            }
        """

        val IDENTITY = floatArrayOf(
            1f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f,
            0f, 0f, 1f, 0f,
            0f, 0f, 0f, 1f
        )
    }
}
