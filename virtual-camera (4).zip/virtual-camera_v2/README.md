# Virtual Camera (Android)

Play a video or an image as your "live camera" — with a draggable floating bubble that
stays on top of YouTube, Zoom, TikTok and every other app.

Kotlin · Gradle · minSdk 24 · targetSdk 34 · Media3/ExoPlayer · Camera2-shaped virtual
device · MediaProjection fallback.

---

## Read this first: what actually works

Android **does not let a normal app inject frames into another app's camera stream.**
That is an architectural boundary, not a missing API: camera frames come from
`cameraserver`, a system daemon that only loads vendor-signed HAL modules from
`/vendor/lib/hw`, and `CameraService` rejects providers whose UID is not allow-listed.

So there are exactly three ways to get your media into another app, and this project
implements the two that a normal APK can do:

| Path | Works on stock Android? | Gets media into YouTube Live? |
|---|---|---|
| **1. Screencast** (YouTube's own screen-share mode) | ✅ Yes | ✅ **Yes — this is the one** |
| **2. Default camera app** (camera intent filters) | ✅ Yes | ❌ No (YouTube never sends the intent) |
| **3. Virtual camera HAL / LSPosed hook** | ❌ Needs root | ✅ Yes |

### ✅ Works out of the box (no root)

- **Media picker** — system Photo Picker (Android 13+) or Storage Access Framework, with
  a *persisted* read grant so the file survives reboots.
- **Looping engine** — ExoPlayer decodes video into an offscreen `SurfaceTexture`; frames
  go to a shared `FrameBus`. Images re-publish on a 1 s tick. Infinite loop, so the
  "camera" never goes black.
- **Floating bubble** — a draggable 56 dp circle over other apps (`SYSTEM_ALERT_WINDOW`),
  owned by the foreground service so it survives app switching. Tap it for the control
  panel: media picker, on/off switch, video/image toggle, recents, Fit/Fill/Stretch/Free,
  zoom slider, position pad, drag-handle editor, stop.
- **Live preview** — renders the *same* `FrameBus` frames the camera path emits, with an
  fps counter. Preview and output cannot drift apart.
- **Foreground service** — `foregroundServiceType="camera|mediaProjection"`, persistent
  notification with Stop.
- **Camera2-shaped virtual device** — `VirtualCameraProvider` + `VirtualCameraDevice` +
  `VirtualCaptureSession` mirror the real API (camera ids, characteristics,
  `DeviceStateCallback`, `CaptureRequest`) and push frames into any `Surface` via EGL.
- **Default-camera-app path** — `CameraIntentActivity` answers all six actions
  (`IMAGE_CAPTURE`, `IMAGE_CAPTURE_SECURE`, `STILL_IMAGE_CAMERA`,
  `STILL_IMAGE_CAMERA_SECURE`, `VIDEO_CAMERA`, `VIDEO_CAPTURE`), shows your media as the
  viewfinder, and on capture writes a JPEG to the caller's `EXTRA_OUTPUT` (or returns a
  thumbnail bitmap + content URI).
- **Fullscreen screencast feed** — `ScreenFeedActivity`: media fills the screen with no
  chrome, ready to be screencast into YouTube Live.
- **MediaProjection fallback** — renders the same frames into a virtual display, for apps
  that accept a *screen share* instead of a camera.

### ⚠️ Needs root / extra setup

- **YouTube's in-app camera, Instagram's in-app camera, TikTok's in-app camera, most Zoom
  builds, WhatsApp video calls.** They open Camera2/CameraX directly and never send a
  camera intent, so they will still show the physical camera. Fixing that needs either a
  **virtual camera HAL** (`camera.virtual.so`, vendor-signed → rooted device or custom
  ROM) or an **LSPosed hook** on `CameraManager.openCamera`. Both are documented below
  with the exact extension points — `VirtualCameraProvider` and `VirtualCameraDevice`
  were written with matching signatures so the hook stays small. They are deliberately
  *not* in this project: neither can ship as a normal APK.
- **Android 14+** shows a per-session screen-capture consent dialog and a permanent
  "screen is being shared" indicator. Unavoidable by design.
- **Video read-back is CPU-bound at 720p** (`glReadPixels` per frame) — chosen so one
  code path serves every consumer. 720p30 is smooth on mid-range hardware; 1080p60 is
  not. See "Performance" below for the GPU-only alternative.

---

## Build & install

### From Android Studio
1. **File → Open** → select this folder (the one containing `settings.gradle.kts`).
2. Let Gradle sync (it will download the Android Gradle Plugin and dependencies).
3. **Run ▶** on a device or emulator (API 24+).

### From the command line
```bash
# point Gradle at your SDK
echo "sdk.dir=$HOME/Android/Sdk" > local.properties

./gradlew :app:assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

A prebuilt debug APK is included as `virtual-camera-debug.apk` if you just want to try it.

### First run
1. Pick a video or an image.
2. Tap **Show floating bubble** → grant **Display over other apps**.
3. Tap the bubble → flip **Virtual camera ON**.

---

## How to use it with YouTube Live

Open the app → **How to use with YouTube Live** (or the bubble's *YouTube guide* button).
The same content, in short:

### Path 1 — Screencast (works today, no root) ⭐

YouTube's Android app can stream your **screen**. That is the only no-root way to put
your media into a real YouTube live stream.

1. In this app, tap **Open fullscreen media feed** — the media fills the screen, no
   controls, screen kept awake.
2. Open **YouTube → Create (＋) → Go live**.
3. Choose **Screencast** (not the camera), then start the stream.
4. Switch back to this app. Your audience sees the media, not the real camera.

Notes:
- YouTube shows a screen-capture indicator, and the stream *is* your screen — so keep
  this app in front. Anything you switch to is broadcast.
- If **Screencast** is missing, update the YouTube app; the option is region- and
  account-gated, and some accounts only get it after the first mobile live stream is
  approved (which can take up to 24 h).
- The bubble still works here: it floats over YouTube, so you can switch media or resize
  mid-stream without leaving the app.

### Path 2 — Set as the default camera app (works for *other* apps)

This app answers `IMAGE_CAPTURE`, `STILL_IMAGE_CAMERA`, `VIDEO_CAMERA` and
`VIDEO_CAPTURE`, so any app that asks the system for a camera through an **intent** gets
this app instead, and receives a frame from your media.

**Settings → Apps → Default apps → Camera app → Virtual Camera**
(path varies by OEM; on some skins it is *Settings → Apps → Default apps → Camera*).

If your OEM removed that selector: open the target app's camera, pick **Virtual Camera**
in the "Open with" dialog, and tap **Always**.

**Honest limit:** YouTube, Instagram, TikTok and most video-call apps open Camera2
directly and never send that intent, so this path does **not** change their camera. It is
here because it is the correct no-root mechanism, and it does work for apps that use the
intent API (many KYC/banking flows, some social apps, the system camera shortcut).

### Path 3 — Root: virtual camera HAL or LSPosed hook

The only way to make YouTube's in-app camera show your media is to replace the camera
below the app layer.

**Option A — virtual camera HAL**
- Write `camera.virtual.so` implementing `camera3_device_ops_t`, backed by a local socket
  that this app feeds from `FrameBus`.
- Register it in `/vendor/etc/camera/camera_config.xml` (or the OEM equivalent) and make
  sure it is vendor-signed.
- Requires an unlocked bootloader, root, and usually a custom ROM or a Magisk module that
  can remount `/vendor`.

**Option B — LSPosed module**
- Hook `CameraManager.openCamera` / `CameraDeviceImpl` inside the target app and redirect
  to this app's `VirtualCameraProvider.openCamera(...)`.
- `VirtualCameraProvider` and `VirtualCameraDevice` deliberately mirror the real Camera2
  signatures (`DeviceStateCallback`, `CaptureRequest`, `createCaptureSession`,
  `CaptureSessionCallback`) so the hook is a thin adapter.
- Requires root + LSPosed (Zygisk).

Neither can ship inside a normal APK — that is why they are documented rather than
included.

---

## Architecture

```
MainActivity ─────────────┐
GuideActivity             │
FrameEditorActivity       ├──► AppStateStore / FrameStyleStore  (SharedPreferences)
ScreenFeedActivity        │              │
PreviewActivity           │              ▼
CameraIntentActivity ─────┘          StateHub  (in-process event bus)
                                          │
                                          ▼
                              VirtualCameraService  (foreground)
                                   │        │        │
                     MediaEngine ──┘        │        └── BubbleOverlay (WindowManager)
                          │                 │
                          ▼                 ▼
                      FrameBus ──────► ScreenCaptureSource (MediaProjection)
                          │
                          ├──► SurfaceFrameWriter ──► SurfaceView (preview / feed / intent)
                          └──► VirtualCameraDevice ──► any Surface (Camera2-shaped)
```

### Key design decisions

**One frame bus, one composition point.** `FrameBus` is the single source of truth.
`FrameStyle` (Fit/Fill/Stretch/Free, zoom, offset) is applied *at the producer* by
`FrameComposer`, so the preview, the Camera2 surface, the projection display, the JPEG
capture and the screencast feed all show the same thing. If each consumer applied the
style itself they would drift apart — and the Camera2 surface, written by a GL thread
that never sees the style, could not honour it at all.

**The default style costs nothing.** `ScaleMode.FILL` with zoom 1 and no offset is a
no-op when the decoder already renders at 1280×720, so normal use pays zero extra work.
A custom layout costs one `Canvas` blit per frame.

**The read-back buffer keeps the source aspect.** `MediaFiles.videoReadbackSize` sizes the
buffer to the video's own aspect (honouring rotation metadata) instead of forcing 16:9.
Cropping at decode time would bake in one choice and make "Fit" impossible to honour.

**Frames are retired, not recycled immediately.** Consumers draw on their own threads and
hold a reference to the frame they are mid-way through drawing. `FrameBus` recycles the
previous frame 250 ms later, which avoids `Canvas: trying to use a recycled bitmap` at
30 fps.

**The bubble lives in the service, not an Activity.** A `TYPE_APPLICATION_OVERLAY` window
owned by the service keeps drawing on top of YouTube while it is in the foreground and
survives app switching. An Activity would be pushed behind the streaming app the moment
it took focus — which is exactly the bug this feature fixes.

**State is in SharedPreferences, not in the service.** `AppStateStore` and
`FrameStyleStore` are the only writers, and they fire `StateHub` events. The bubble, the
main screen and the camera-intent activity therefore agree without talking to each other,
and everything survives process death and reboot.

### Files worth reading

| File | What it does |
|---|---|
| `camera/FrameBus.kt` | The frame pipeline + style composition + safe recycling |
| `render/FrameComposer.kt` | Bakes `FrameStyle` into output frames |
| `data/FrameStyle.kt` | The layout model; `destinationRect()` is the single geometry source |
| `data/AppState.kt` | Persisted state (two media slots, on/off, bubble, recents) |
| `overlay/BubbleOverlay.kt` | The draggable bubble + control panel |
| `render/FrameEditorView.kt` | Drag-handle editor (corner resize, move, pinch) |
| `service/VirtualCameraService.kt` | Owner of engine, projection, virtual device, bubble |
| `camera/VirtualCameraProvider.kt` | The Camera2-shaped seam for a HAL / LSPosed backend |
| `ScreenFeedActivity.kt` | The fullscreen feed for YouTube's Screencast mode |

---

## Performance

The video path is `MediaCodec → SurfaceTexture → glReadPixels → Bitmap → Canvas → GL blit`.
The `glReadPixels` is the expensive step (~4–8 ms at 720p on mid-range hardware), and it
exists so that one frame can reach five different consumers without sharing a GL context.

If you need 1080p60, replace it with a GPU-only path:
- Share the EGL context between ExoPlayer's `SurfaceTexture` and the consumer surface, or
- Drive `MediaCodec` straight into `eglCreateWindowSurface` and skip the Bitmap entirely.

Both are contained changes: `MediaEngine.startBitmapPump` and `SurfaceFrameWriter` are the
only two places that would need to change, because everything downstream already reads
from `FrameBus`.

---

## Permissions

| Permission | Why |
|---|---|
| `CAMERA` | Required for `foregroundServiceType="camera"` on Android 14+ and for reliable `IMAGE_CAPTURE` resolution. The app never opens the physical camera. |
| `SYSTEM_ALERT_WINDOW` | The floating bubble. Granted in Settings, not by a runtime dialog. |
| `FOREGROUND_SERVICE` + `_CAMERA` + `_MEDIA_PROJECTION` | Keep the feed alive in the background. |
| `POST_NOTIFICATIONS` | The ongoing notification. |
| `READ_MEDIA_VIDEO` / `READ_MEDIA_IMAGES` | Only for the MediaStore shortcut; the picker itself uses SAF and needs no permission. |

---

## Known limitations

- **YouTube's in-app camera cannot be replaced without root.** Stated plainly, in the app
  and here. Use Screencast.
- **Screencast broadcasts your whole screen.** Keep this app in front; notifications and
  other apps are visible to the audience.
- **MediaProjection is not the YouTube path.** YouTube's mobile app does not consume
  another app's projection — its Screencast mode captures the screen itself. The
  projection fallback is for desktop/streaming apps that accept a screen share.
- **720p30 ceiling** on the CPU read-back path (see Performance).
- **The bubble needs the overlay permission.** Without it the app still works; you just
  control it from the app instead of over other apps.
- **Some OEMs kill foreground services aggressively** (Xiaomi, Huawei, Samsung). If the
  feed stops when you switch apps, disable battery optimisation for this app.

---

## Acceptance checklist

Run this on a real device before relying on it for a live stream:

- [ ] Pick a video → preview loops, fps counter shows ~30.
- [ ] Pick an image → preview shows it, no flicker.
- [ ] Bubble appears, drags, snaps back to where you left it after a restart.
- [ ] Bubble panel: on/off switch stops and resumes the feed instantly.
- [ ] Video/image toggle switches without a re-pick.
- [ ] Recents chip switches media; long-press removes it.
- [ ] Fit / Fill / Stretch / Free visibly change the output; zoom slider and position pad
      work; drag handles resize freely.
- [ ] Layout survives an app restart.
- [ ] `ScreenFeedActivity` fills the screen, hint bar auto-hides, tap brings it back.
- [ ] YouTube → Create → Go live → **Screencast** shows the media to the audience.
- [ ] Set as default camera app → another app's `IMAGE_CAPTURE` returns a frame from your
      media.
- [ ] MediaProjection fallback starts, shows the consent dialog, and mirrors the media.

---

## License

Provided as-is for personal and educational use. The virtual-camera HAL and LSPosed
approaches are documented for completeness; using them may violate the terms of service
of some platforms and the warranty of your device.
